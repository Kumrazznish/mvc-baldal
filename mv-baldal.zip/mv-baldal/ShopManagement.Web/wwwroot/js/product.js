// ============================================================
// Product Inventory Module (AJAX & Event Handlers)
// ============================================================

var upsertModal, editModal;
var allProducts = [];

$(document).ready(function () {
    if (document.getElementById('upsertProductModal')) {
        upsertModal = new bootstrap.Modal(document.getElementById('upsertProductModal'));
    }
    if (document.getElementById('editProductModal')) {
        editModal = new bootstrap.Modal(document.getElementById('editProductModal'));
    }

    loadProducts();

    $("#upsertProductForm").on("submit", function (e) {
        e.preventDefault();
        saveUpsertProduct();
    });

    $("#editProductForm").on("submit", function (e) {
        e.preventDefault();
        saveEditProduct();
    });

    $("#txtProductSearch").on("input", function () {
        filterProducts();
    });
});

function loadProducts() {
    var $tbody = $("#productsTbody");
    $tbody.html('<tr><td colspan="7" class="text-center py-3 text-muted">Loading products...</td></tr>');

    $.ajax({
        url: "/Product/GetProductsJson",
        type: "GET",
        dataType: "json"
    }).done(function (data) {
        if (typeof data === "string") {
            try { data = JSON.parse(data); } catch (e) { }
        }
        allProducts = Array.isArray(data) ? data : [];
        renderProducts(allProducts);
    }).fail(function () {
        $tbody.html('<tr><td colspan="7" class="text-center py-3 text-danger">Error loading products.</td></tr>');
    });
}

function renderProducts(list) {
    var $tbody = $("#productsTbody");
    if (!list || list.length === 0) {
        $tbody.html('<tr><td colspan="7" class="text-center py-4 text-muted">No products found.</td></tr>');
        return;
    }

    var html = '';
    list.forEach(function (p, index) {
        var imgSrc = p.ImagePath ? p.ImagePath : '/images/products/default-product.svg';
        var stockBadge = p.Quantity <= 5 
            ? `<span class="badge bg-danger">${p.Quantity} (Low)</span>` 
            : `<span class="badge bg-success">${p.Quantity}</span>`;

        html += `
            <tr>
                <td class="text-center text-muted">${index + 1}</td>
                <td>
                    <img src="${imgSrc}" style="width:40px;height:40px;object-fit:cover;border:1px solid #ddd;border-radius:4px;" 
                         onerror="this.src='/images/products/default-product.svg'" />
                </td>
                <td class="font-monospace fw-bold">${escapeHtml(p.ProductCode || '')}</td>
                <td>${escapeHtml(p.ProductName || '')}</td>
                <td>${stockBadge}</td>
                <td class="fw-bold">₹${parseFloat(p.Price || 0).toFixed(2)}</td>
                <td class="text-end">
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="openEditModal(${p.ProductId})">
                        Edit
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteProduct(${p.ProductId}, '${escapeHtml(p.ProductName || '')}')">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    });

    $tbody.html(html);
}

function filterProducts() {
    var q = ($("#txtProductSearch").val() || "").toLowerCase().trim();
    if (!q) {
        renderProducts(allProducts);
        return;
    }
    var filtered = allProducts.filter(function (p) {
        return (p.ProductCode && p.ProductCode.toLowerCase().includes(q)) ||
               (p.ProductName && p.ProductName.toLowerCase().includes(q));
    });
    renderProducts(filtered);
}

function openUpsertModal() {
    $("#upsertProductForm")[0].reset();
    $("#upsert_imgPreview").attr("src", "/images/products/default-product.svg");
    upsertModal.show();
}

function saveUpsertProduct() {
    var form = document.getElementById("upsertProductForm");
    var formData = new FormData(form);
    var btn = $("#btnUpsertSave");
    btn.prop("disabled", true).text("Saving...");

    $.ajax({
        url: "/Product/Add",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false
    }).done(function (res) {
        btn.prop("disabled", false).text("Save Product");
        if (res.success) {
            upsertModal.hide();
            Swal.fire({ icon: 'success', title: 'Saved', text: res.message, timer: 1500, showConfirmButton: false });
            loadProducts();
        } else {
            Swal.fire({ icon: 'error', title: 'Error', text: res.message });
        }
    }).fail(function () {
        btn.prop("disabled", false).text("Save Product");
        Swal.fire({ icon: 'error', title: 'Error', text: 'Server error while saving product.' });
    });
}

function openEditModal(productId) {
    var p = allProducts.find(x => x.ProductId === productId);
    if (!p) return;

    $("#edit_productId").val(p.ProductId);
    $("#edit_productCode").val(p.ProductCode);
    $("#edit_productName").val(p.ProductName);
    $("#edit_quantity").val(p.Quantity);
    $("#edit_price").val(p.Price);
    $("#edit_imgPreview").attr("src", p.ImagePath ? p.ImagePath : "/images/products/default-product.svg");
    $("#edit_imageFile").val('');

    editModal.show();
}

function saveEditProduct() {
    var form = document.getElementById("editProductForm");
    var formData = new FormData(form);
    var btn = $("#btnEditSave");
    btn.prop("disabled", true).text("Saving...");

    $.ajax({
        url: "/Product/Edit",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false
    }).done(function (res) {
        btn.prop("disabled", false).text("Save Changes");
        if (res.success) {
            editModal.hide();
            Swal.fire({ icon: 'success', title: 'Updated', text: res.message, timer: 1500, showConfirmButton: false });
            loadProducts();
        } else {
            Swal.fire({ icon: 'error', title: 'Error', text: res.message });
        }
    }).fail(function () {
        btn.prop("disabled", false).text("Save Changes");
        Swal.fire({ icon: 'error', title: 'Error', text: 'Server error while updating product.' });
    });
}

function deleteProduct(productId, name) {
    Swal.fire({
        title: 'Delete Product?',
        text: `Are you sure you want to deactivate "${name}"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete',
        confirmButtonColor: '#dc3545'
    }).then(result => {
        if (result.isConfirmed) {
            $.post("/Product/Delete", { productId: productId }, function (res) {
                if (res.success) {
                    Swal.fire({ icon: 'success', title: 'Deleted', text: res.message, timer: 1500, showConfirmButton: false });
                    loadProducts();
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
            });
        }
    });
}

function previewFileImage(input, previewId) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById(previewId).src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>"']/g, function (m) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
}
