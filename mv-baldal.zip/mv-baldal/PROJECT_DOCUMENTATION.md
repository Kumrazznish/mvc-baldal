# 🏪 Shop Management System (3-Tier Architecture) — Complete Project Guide & Documentation

> **Project Architecture:** ASP.NET Core 8/10 MVC (Presentation Layer) + Business Access Layer (BAL) + Data Access Layer (DAL) + MySQL Database  
> **UI Components:** Kendo UI, jQuery, Bootstrap 5, FontAwesome 6, SweetAlert2  
> **Key Capabilities:** Multi-Role (Admin & Employee/Desk Cashier), Dynamic POS Billing with Real-time Stock Deduction, Product Upsert (Auto-stock increment), Excel Bulk Import/Export via ClosedXML, Store Management, Invoice Printing.

---

## 📑 Table of Contents

1. [Architecture & System Flow Overview](#1-architecture--system-flow-overview)
2. [Database Design & Complete SQL Scripts](#2-database-design--complete-sql-scripts)
   - [2.1 Complete Database Creation Script](#21-complete-database-creation-script)
   - [2.2 Table Schemas & Foreign Keys](#22-table-schemas--foreign-keys)
   - [2.3 Seed / Initial Data](#23-seed--initial-data)
   - [2.4 Production Stored Procedures](#24-production-stored-procedures)
3. [Step-by-Step Project Creation from Scratch](#3-step-by-step-project-creation-from-scratch)
   - [3.1 Solution & Project Initialization](#31-solution--project-initialization)
   - [3.2 Adding Project References (Wiring Layers)](#32-adding-project-references-wiring-layers)
   - [3.3 Installing NuGet Packages](#33-installing-nuget-packages)
4. [Complete Solution Folder Structure](#4-complete-solution-folder-structure)
5. [Layer-by-Layer Complete Source Code](#5-layer-by-layer-complete-source-code)
   - [5.1 Data Access Layer (ShopManagement.DataAccess)](#51-data-access-layer-shopmanagementdataaccess)
     - [`ShopManagement.DataAccess.csproj`](#511-shopmanagementdataaccesscsproj)
     - [`DbHelper.cs`](#512-dbhelpercs)
     - [`AccountDAL.cs`](#513-accountdalcs)
     - [`ProductDAL.cs`](#514-productdalcs)
     - [`StoreDAL.cs`](#515-storedalcs)
     - [`EmployeeDAL.cs`](#516-employeedalcs)
     - [`InvoiceDAL.cs`](#517-invoicedalcs)
   - [5.2 Business Access Layer (ShopManagement.Business)](#52-business-access-layer-shopmanagementbusiness)
     - [`ShopManagement.Business.csproj`](#521-shopmanagementbusinesscsproj)
     - [`AccountBAL.cs`](#522-accountbalcs)
     - [`ProductBAL.cs`](#523-productbalcs)
     - [`StoreBAL.cs`](#524-storebalcs)
     - [`EmployeeBAL.cs`](#525-employeebalcs)
     - [`InvoiceBAL.cs`](#526-invoicebalcs)
     - [`ExcelBAL.cs`](#527-excelbalcs)
   - [5.3 Web Presentation Layer (ShopManagement.Web)](#53-web-presentation-layer-shopmanagementweb)
     - [`ShopManagement.Web.csproj`](#531-shopmanagementwebcsproj)
     - [`appsettings.json`](#532-appsettingsjson)
     - [`Program.cs`](#533-programcs)
     - [`AccountController.cs`](#534-accountcontrollercs)
     - [`DashboardController.cs`](#535-dashboardcontrollercs)
     - [`ProductController.cs`](#536-productcontrollercs)
     - [`StoreController.cs`](#537-storecontrollercs)
     - [`EmployeeController.cs`](#538-employeecontrollercs)
     - [`InvoiceController.cs`](#539-invoicecontrollercs)
     - [`Views/Shared/_Layout.cshtml`](#5310-viewsshared_layoutcshtml)
     - [`Views/Account/Login.cshtml`](#5311-viewsaccountlogincshtml)
     - [`Views/Product/Index.cshtml`](#5312-viewsproductindexcshtml)
     - [`wwwroot/js/product.js`](#5313-wwwrootjsproductjs)
     - [`Views/Product/Import.cshtml`](#5314-viewsproductimportcshtml)
     - [`Views/Invoice/Create.cshtml`](#5315-viewsinvoicecreatecshtml)
     - [`Views/Invoice/History.cshtml`](#5316-viewsinvoicehistorycshtml)
     - [`Views/Employee/Index.cshtml`](#5317-viewsemployeeindexcshtml)
     - [`Views/Store/Index.cshtml`](#5318-viewsstoreindexcshtml)
6. [End-to-End Data Flow Deep Dive](#6-end-to-end-data-flow-deep-dive)
7. [Step-by-Step Setup, Build & Run Guide](#7-step-by-step-setup-build--run-guide)

---

# 1. Architecture & System Flow Overview

The system is constructed strictly according to the **3-Tier Separation of Concerns** design pattern:

```
┌────────────────────────────────────────────────────────────────────────┐
│                   PRESENTATION LAYER (ShopManagement.Web)              │
│  - ASP.NET Core MVC Controllers & Views                                │
│  - Kendo UI Grids, SweetAlert2, Bootstrap 5 UI, AJAX Endpoints         │
│  - Session-based Authentication & Role authorization (Admin/Employee)  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ (Calls BLL methods)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   BUSINESS LOGIC LAYER (ShopManagement.Business)       │
│  - Input validation, Sanitization, Business calculations               │
│  - Stock thresholds & Upsert logic handling                            │
│  - ClosedXML Excel streaming and batch parsing                         │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ (Calls DAL methods)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   DATA ACCESS LAYER (ShopManagement.DataAccess)        │
│  - ADO.NET abstraction via DbHelper (MySqlConnector)                  │
│  - Parameterized SQL Queries & Stored Procedures (SQL Injection Safe)  │
│  - Database Transactions (ACID compliance for Billing & Stock)         │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ (SQL Port: 3306)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                         MYSQL DATABASE (ShopManagementDB)              │
│  - Tables: Users, Stores, Products, Invoices, InvoiceDetails           │
│  - Foreign Keys, Auto-increments, Unique Indexes                       │
└────────────────────────────────────────────────────────────────────────┘
```

### Complete End-to-End Data Pipeline:
```
[User Browser Action]
         │ (HTTP GET/POST / AJAX)
         ▼
[MVC Controller Action]
         │ (Extracts Form / JSON / Query params)
         ▼
[Business Access Layer (BAL)]
         │ (Validates rules, checks parameters)
         ▼
[Data Access Layer (DAL)]
         │ (Executes SQL with MySqlParameter / Stored Proc)
         ▼
[MySQL Database Engine]
         │ (Returns raw records / rows)
         ▼
[DAL: DbHelper.ExecuteDataTable]
         │ (Fills ADO.NET DataTable)
         ▼
[BAL: Returns DataTable / Result Object]
         ▼
[Controller: Serialize to JSON Array / Dictionary]
         │ (Returns application/json)
         ▼
[Client: Kendo Grid / AJAX Callback]
         │ (Renders rows, updates DOM, triggers alert)
         ▼
[Screen Updated for User]
```

---

# 2. Database Design & Complete SQL Scripts

## 2.1 Complete Database Creation Script

Save this script as `Database_Setup.sql` and execute it in MySQL Workbench, phpMyAdmin, or MySQL CLI:

```sql
-- ============================================================
-- DATABASE CREATION: ShopManagementDB
-- ============================================================
CREATE DATABASE IF NOT EXISTS ShopManagementDB;
USE ShopManagementDB;

-- 1. STORES TABLE
CREATE TABLE IF NOT EXISTS Stores (
    StoreId INT AUTO_INCREMENT PRIMARY KEY,
    StoreName VARCHAR(200) NOT NULL,
    StoreCode VARCHAR(50) NOT NULL UNIQUE,
    Address VARCHAR(500) NULL,
    Phone VARCHAR(20) NULL,
    Email VARCHAR(150) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

-- 2. USERS TABLE
CREATE TABLE IF NOT EXISTS Users (
    UserId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Username VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL, -- 'Admin', 'Employee'
    StoreId INT NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL,
    CONSTRAINT FK_Users_Stores FOREIGN KEY (StoreId) REFERENCES Stores(StoreId) ON DELETE SET NULL
);

-- 3. PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS Products (
    ProductId INT AUTO_INCREMENT PRIMARY KEY,
    ProductCode VARCHAR(50) NOT NULL UNIQUE,
    ProductName VARCHAR(200) NOT NULL,
    Quantity INT NOT NULL DEFAULT 0,
    Price DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    ImagePath VARCHAR(500) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

-- 4. INVOICES TABLE (BILL HEADER)
CREATE TABLE IF NOT EXISTS Invoices (
    InvoiceId INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceNo VARCHAR(30) NOT NULL UNIQUE,
    CustomerName VARCHAR(150) NOT NULL,
    CustomerPhone VARCHAR(20) NULL,
    CreatedBy INT NOT NULL,
    StoreId INT NULL,
    InvoiceDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    CONSTRAINT FK_Invoices_Users FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
    CONSTRAINT FK_Invoices_Stores FOREIGN KEY (StoreId) REFERENCES Stores(StoreId) ON DELETE SET NULL
);

-- 5. INVOICE DETAILS TABLE (BILL LINE ITEMS)
CREATE TABLE IF NOT EXISTS InvoiceDetails (
    InvoiceDetailId INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceId INT NOT NULL,
    ProductId INT NOT NULL,
    ProductName VARCHAR(200) NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    TotalAmount DECIMAL(18,2) NOT NULL,
    CONSTRAINT FK_InvoiceDetails_Invoices FOREIGN KEY (InvoiceId) REFERENCES Invoices(InvoiceId) ON DELETE CASCADE,
    CONSTRAINT FK_InvoiceDetails_Products FOREIGN KEY (ProductId) REFERENCES Products(ProductId)
);
```

## 2.2 Table Schemas & Foreign Keys

| Table Name | Purpose | Primary Key | Key Foreign Keys |
| :--- | :--- | :--- | :--- |
| **`Stores`** | Multi-branch/store management | `StoreId` | None |
| **`Users`** | System Logins (Admin & Cashiers) | `UserId` | `StoreId` → `Stores.StoreId` |
| **`Products`** | Inventory items, codes, stock & prices | `ProductId` | Unique Index on `ProductCode` |
| **`Invoices`** | Bill master receipt summary | `InvoiceId` | `CreatedBy` → `Users.UserId`, `StoreId` → `Stores.StoreId` |
| **`InvoiceDetails`**| Individual items sold in each bill | `InvoiceDetailId` | `InvoiceId` → `Invoices.InvoiceId`, `ProductId` → `Products.ProductId` |

## 2.3 Seed / Initial Data

```sql
-- 1. Insert Default Store
INSERT IGNORE INTO Stores (StoreId, StoreName, StoreCode, Address, Phone, Email, IsActive)
VALUES (1, 'Main Branch', 'MAIN01', '123 Market Road, City Centre', '9800000001', 'main@shopdesk.local', 1);

-- 2. Insert Default Users
-- Admin login: admin / admin123
-- Desk Cashier login: desk1 / desk123 (tied to Main Branch)
INSERT IGNORE INTO Users (UserId, Name, Username, PasswordHash, Role, StoreId, IsActive)
VALUES 
(1, 'System Admin', 'admin', 'admin123', 'Admin', 1, 1),
(2, 'Desk Cashier', 'desk1', 'desk123', 'Employee', 1, 1);

-- 3. Insert Initial Product Inventory
INSERT IGNORE INTO Products (ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive)
VALUES 
(1, 'P001', 'Parker Roller Ball Pen', 100, 150.00, '/images/products/default-product.svg', 1),
(2, 'P002', 'Classmate Spiral Notebook A4', 50, 85.00, '/images/products/default-product.svg', 1),
(3, 'P003', 'Apsara Platinum Pencil Set', 120, 45.00, '/images/products/default-product.svg', 1),
(4, 'P004', 'Camlin Neon Highlighter Pack', 60, 110.00, '/images/products/default-product.svg', 1),
(5, 'P005', 'Casio Desk Calculator', 35, 450.00, '/images/products/default-product.svg', 1);
```

## 2.4 Production Stored Procedures

Below are stored procedures that can be used directly in MySQL for enterprise production environments:

```sql
DELIMITER $$

-- Procedure 1: Validate User for Login
DROP PROCEDURE IF EXISTS sp_ValidateUser$$
CREATE PROCEDURE sp_ValidateUser(
    IN p_Username VARCHAR(100),
    IN p_Password VARCHAR(255)
)
BEGIN
    SELECT UserId, Name, Username, Role, StoreId, IsActive 
    FROM Users 
    WHERE Username = p_Username AND PasswordHash = p_Password AND IsActive = 1;
END$$

-- Procedure 2: Get All Active Products
DROP PROCEDURE IF EXISTS sp_GetAllProducts$$
CREATE PROCEDURE sp_GetAllProducts(
    IN p_ActiveOnly BOOLEAN
)
BEGIN
    IF p_ActiveOnly THEN
        SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate, UpdatedDate 
        FROM Products 
        WHERE IsActive = 1 
        ORDER BY ProductId DESC;
    ELSE
        SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate, UpdatedDate 
        FROM Products 
        ORDER BY ProductId DESC;
    END IF;
END$$

-- Procedure 3: Search Active In-Stock Products for POS Counter
DROP PROCEDURE IF EXISTS sp_SearchAvailableProducts$$
CREATE PROCEDURE sp_SearchAvailableProducts(
    IN p_SearchTerm VARCHAR(100)
)
BEGIN
    SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath
    FROM Products
    WHERE IsActive = 1 AND Quantity > 0
      AND (ProductName LIKE CONCAT('%', p_SearchTerm, '%') OR ProductCode LIKE CONCAT('%', p_SearchTerm, '%'))
    ORDER BY ProductName ASC;
END$$

-- Procedure 4: Upsert Product (Insert or Add Stock)
DROP PROCEDURE IF EXISTS sp_UpsertProduct$$
CREATE PROCEDURE sp_UpsertProduct(
    IN p_ProductCode VARCHAR(50),
    IN p_ProductName VARCHAR(200),
    IN p_Quantity INT,
    IN p_Price DECIMAL(18,2),
    IN p_ImagePath VARCHAR(500),
    OUT p_Result VARCHAR(100)
)
BEGIN
    DECLARE v_ExistingId INT DEFAULT NULL;
    DECLARE v_ExistingImg VARCHAR(500) DEFAULT NULL;

    SELECT ProductId, ImagePath INTO v_ExistingId, v_ExistingImg
    FROM Products
    WHERE ProductCode = p_ProductCode OR LOWER(ProductName) = LOWER(p_ProductName)
    LIMIT 1;

    IF v_ExistingId IS NOT NULL THEN
        UPDATE Products
        SET ProductName = p_ProductName,
            Quantity = Quantity + p_Quantity,
            Price = p_Price,
            ImagePath = COALESCE(NULLIF(p_ImagePath, ''), v_ExistingImg, '/images/products/default-product.svg'),
            IsActive = 1,
            UpdatedDate = NOW()
        WHERE ProductId = v_ExistingId;
        SET p_Result = 'Updated (Stock Incremented)';
    ELSE
        INSERT INTO Products (ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate)
        VALUES (
            p_ProductCode, 
            p_ProductName, 
            p_Quantity, 
            p_Price, 
            COALESCE(NULLIF(p_ImagePath, ''), '/images/products/default-product.svg'), 
            1, 
            NOW()
        );
        SET p_Result = 'Created New Product';
    END IF;
END$$

-- Procedure 5: Get Invoice Summary History
DROP PROCEDURE IF EXISTS sp_GetInvoiceHistory$$
CREATE PROCEDURE sp_GetInvoiceHistory(
    IN p_CreatedBy INT
)
BEGIN
    IF p_CreatedBy IS NULL OR p_CreatedBy <= 0 THEN
        SELECT 
            i.InvoiceId, i.InvoiceNo, i.CustomerName, i.CustomerPhone, 
            i.TotalAmount, i.InvoiceDate, u.Name AS CreatedByName, u.Role AS CreatedByRole
        FROM Invoices i
        INNER JOIN Users u ON i.CreatedBy = u.UserId
        ORDER BY i.InvoiceId DESC;
    ELSE
        SELECT 
            i.InvoiceId, i.InvoiceNo, i.CustomerName, i.CustomerPhone, 
            i.TotalAmount, i.InvoiceDate, u.Name AS CreatedByName, u.Role AS CreatedByRole
        FROM Invoices i
        INNER JOIN Users u ON i.CreatedBy = u.UserId
        WHERE i.CreatedBy = p_CreatedBy
        ORDER BY i.InvoiceId DESC;
    END IF;
END$$

-- Procedure 6: Get Dashboard Metrics (Counters)
DROP PROCEDURE IF EXISTS sp_GetDashboardMetrics$$
CREATE PROCEDURE sp_GetDashboardMetrics()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM Products WHERE IsActive = 1) AS TotalProducts,
        (SELECT COUNT(*) FROM Products WHERE IsActive = 1 AND Quantity <= 10) AS LowStockProducts,
        (SELECT COUNT(*) FROM Invoices) AS TotalInvoices,
        (SELECT COALESCE(SUM(TotalAmount), 0) FROM Invoices) AS TotalRevenue,
        (SELECT COUNT(*) FROM Users WHERE Role = 'Employee' AND IsActive = 1) AS TotalEmployees;
END$$

DELIMITER ;
```

---

# 3. Step-by-Step Project Creation from Scratch

Follow these exact terminal commands or Visual Studio steps to recreate this complete 3-Tier solution from scratch.

## 3.1 Solution & Project Initialization

Open your terminal (PowerShell, Command Prompt, or Bash) in your preferred root folder (e.g. `d:\Download\mv-baldal`):

```bash
# 1. Create a blank Solution file
dotnet new sln -n ShopManagement

# 2. Create the Data Access Layer Class Library (.NET 8/10)
dotnet new classlib -n ShopManagement.DataAccess

# 3. Create the Business Access Layer Class Library (.NET 8/10)
dotnet new classlib -n ShopManagement.Business

# 4. Create the Web MVC Project (.NET 8/10)
dotnet new mvc -n ShopManagement.Web

# 5. Add all 3 projects to the Solution
dotnet sln add ShopManagement.DataAccess/ShopManagement.DataAccess.csproj
dotnet sln add ShopManagement.Business/ShopManagement.Business.csproj
dotnet sln add ShopManagement.Web/ShopManagement.Web.csproj
```

## 3.2 Adding Project References (Wiring Layers)

The dependencies must flow strictly in one direction:  
`Web` ➔ depends on ➔ `Business` & `DataAccess`  
`Business` ➔ depends on ➔ `DataAccess`  
`DataAccess` ➔ does not depend on any application layer.

```bash
# Reference DataAccess inside Business Layer
dotnet add ShopManagement.Business/ShopManagement.Business.csproj reference ShopManagement.DataAccess/ShopManagement.DataAccess.csproj

# Reference Business Layer inside Web Layer
dotnet add ShopManagement.Web/ShopManagement.Web.csproj reference ShopManagement.Business/ShopManagement.Business.csproj

# Reference DataAccess Layer inside Web Layer (for Startup initializations)
dotnet add ShopManagement.Web/ShopManagement.Web.csproj reference ShopManagement.DataAccess/ShopManagement.DataAccess.csproj
```

## 3.3 Installing NuGet Packages

```bash
# Install MySqlConnector in DataAccess (High-performance native ADO.NET driver)
cd ShopManagement.DataAccess
dotnet add package MySqlConnector --version 2.6.2
cd ..

# Install ClosedXML in Business (For Excel generation & batch import reading)
cd ShopManagement.Business
dotnet add package ClosedXML --version 0.105.1
cd ..

# Install Newtonsoft.Json in Web (For high-speed JSON serialization of DataTables)
cd ShopManagement.Web
dotnet add package Newtonsoft.Json --version 13.0.4
cd ..
```

---

# 4. Complete Solution Folder Structure

```
d:\Download\mv-baldal\
│
├── ShopManagement.sln                   # Master Solution File
├── Database_Setup.sql                   # SQL Creation & Migration Script
│
├── ShopManagement.DataAccess/           # DATA ACCESS LAYER (DAL)
│   ├── ShopManagement.DataAccess.csproj # DAL Project File (Dependencies)
│   ├── DbHelper.cs                      # ADO.NET Core helper & DB auto-initializer
│   ├── AccountDAL.cs                    # User queries
│   ├── ProductDAL.cs                    # Product CRUD, Stock Upsert queries
│   ├── StoreDAL.cs                      # Stores queries & branch aggregations
│   ├── EmployeeDAL.cs                   # Desk cashier queries & status toggles
│   └── InvoiceDAL.cs                    # Transactional billing & stock deduct queries
│
├── ShopManagement.Business/             # BUSINESS LOGIC LAYER (BAL)
│   ├── ShopManagement.Business.csproj   # BAL Project File
│   ├── AccountBAL.cs                    # Login sanitization & authentication logic
│   ├── ProductBAL.cs                    # Product validation & stock upsert logic
│   ├── StoreBAL.cs                      # Store validation & rules
│   ├── EmployeeBAL.cs                   # Employee validation & unique constraints
│   ├── InvoiceBAL.cs                    # Invoice items & total validation
│   └── ExcelBAL.cs                      # ClosedXML spreadsheet parsing & templates
│
└── ShopManagement.Web/                  # PRESENTATION LAYER (MVC WEB APP)
    ├── ShopManagement.Web.csproj        # Web Project File
    ├── appsettings.json                 # DB Connection Strings & configs
    ├── Program.cs                       # App entry point, Session, DI, Routing
    │
    ├── Controllers/
    │   ├── AccountController.cs         # Login, Session & Logout handling
    │   ├── DashboardController.cs       # Admin KPI cards & metrics
    │   ├── ProductController.cs         # Product Grid API, Modal Upsert, Excel actions
    │   ├── StoreController.cs           # Store CRUD API
    │   ├── EmployeeController.cs        # Desk Logins CRUD API
    │   └── InvoiceController.cs         # POS Billing & Invoice History API
    │
    ├── Views/
    │   ├── _ViewImports.cshtml          # Global TagHelpers & namespaces
    │   ├── _ViewStart.cshtml            # Default Layout definition
    │   ├── Shared/
    │   │   └── _Layout.cshtml           # Master Layout (Sidebar, Navbar, Scripts)
    │   ├── Account/
    │   │   └── Login.cshtml             # Login page
    │   ├── Dashboard/
    │   │   └── Index.cshtml             # Metrics dashboard
    │   ├── Product/
    │   │   ├── Index.cshtml             # Product Management (Kendo Grid & Modals)
    │   │   └── Import.cshtml            # Excel Bulk Import UI
    │   ├── Store/
    │   │   └── Index.cshtml             # Stores Management (Kendo Grid)
    │   ├── Employee/
    │   │   └── Index.cshtml             # Desk Cashiers (Kendo Grid & Modals)
    │   └── Invoice/
    │       ├── Create.cshtml            # POS Live Billing Counter
    │       └── History.cshtml           # Invoice History & Printable Bill Modal
    │
    └── wwwroot/                         # Static Assets
        ├── css/site.css                 # Clean minimalistic CSS overrides
        ├── js/
        │   ├── product.js               # Kendo Grid initialization & AJAX handlers
        │   └── site.js                  # General application scripts
        ├── images/products/             # Default product icons & SVGs
        └── uploads/products/            # User-uploaded product image files
```

---

# 5. Layer-by-Layer Complete Source Code

---

## 5.1 Data Access Layer (`ShopManagement.DataAccess`)

### 5.1.1 `ShopManagement.DataAccess.csproj`
```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="MySqlConnector" Version="2.6.2" />
  </ItemGroup>

</Project>
```

### 5.1.2 `DbHelper.cs`
**File Path:** `ShopManagement.DataAccess/DbHelper.cs`  
**Role:** Manages MySQL connections, executes queries returning `DataTable`, scalar values, or affected rows, and runs automatic table migration if the database is newly created.

```csharp
using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public static class DbHelper
    {
        public static string ConnectionString { get; set; } = "Server=localhost;Database=ShopManagementDB;User ID=root;Password=root;Port=3306;AllowUserVariables=True;";

        public static MySqlConnection GetConnection()
        {
            var conn = new MySqlConnection(ConnectionString);
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            return conn;
        }

        public static DataTable ExecuteDataTable(string query, MySqlParameter[] parameters = null, CommandType commandType = CommandType.Text)
        {
            var dt = new DataTable();
            using (var conn = GetConnection())
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.CommandType = commandType;
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }

                using (var adapter = new MySqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        public static int ExecuteNonQuery(string query, MySqlParameter[] parameters = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = GetConnection())
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.CommandType = commandType;
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteNonQuery();
            }
        }

        public static object ExecuteScalar(string query, MySqlParameter[] parameters = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = GetConnection())
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.CommandType = commandType;
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteScalar();
            }
        }

        public static void InitializeDatabase()
        {
            try
            {
                // Create tables if not exist
                string createTablesSql = @"
CREATE TABLE IF NOT EXISTS Stores (
    StoreId INT AUTO_INCREMENT PRIMARY KEY,
    StoreName VARCHAR(200) NOT NULL,
    StoreCode VARCHAR(50) NOT NULL UNIQUE,
    Address VARCHAR(500) NULL,
    Phone VARCHAR(20) NULL,
    Email VARCHAR(150) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

CREATE TABLE IF NOT EXISTS Users (
    UserId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Username VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL,
    StoreId INT NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

CREATE TABLE IF NOT EXISTS Products (
    ProductId INT AUTO_INCREMENT PRIMARY KEY,
    ProductCode VARCHAR(50) NOT NULL UNIQUE,
    ProductName VARCHAR(200) NOT NULL,
    Quantity INT NOT NULL DEFAULT 0,
    Price DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    ImagePath VARCHAR(500) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

CREATE TABLE IF NOT EXISTS Invoices (
    InvoiceId INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceNo VARCHAR(30) NOT NULL UNIQUE,
    CustomerName VARCHAR(150) NOT NULL,
    CustomerPhone VARCHAR(20) NULL,
    CreatedBy INT NOT NULL,
    StoreId INT NULL,
    InvoiceDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0.00
);

CREATE TABLE IF NOT EXISTS InvoiceDetails (
    InvoiceDetailId INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceId INT NOT NULL,
    ProductId INT NOT NULL,
    ProductName VARCHAR(200) NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    TotalAmount DECIMAL(18,2) NOT NULL
);";
                ExecuteNonQuery(createTablesSql);

                // Auto Seed Defaults
                try
                {
                    ExecuteNonQuery(@"
INSERT IGNORE INTO Users (UserId, Name, Username, PasswordHash, Role, IsActive)
VALUES 
(1, 'System Admin', 'admin', 'admin123', 'Admin', 1),
(2, 'Desk Cashier', 'desk1', 'desk123', 'Employee', 1);");
                }
                catch { }

                try
                {
                    ExecuteNonQuery(@"
INSERT IGNORE INTO Stores (StoreId, StoreName, StoreCode, Address, Phone, Email, IsActive)
VALUES (1, 'Main Branch', 'MAIN01', '123 Market Road, City Centre', '9800000001', 'main@shopdesk.local', 1);");
                }
                catch { }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DbHelper.InitializeDatabase] Warning: {ex.Message}");
            }
        }
    }
}
```

### 5.1.3 `AccountDAL.cs`
**File Path:** `ShopManagement.DataAccess/AccountDAL.cs`

```csharp
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class AccountDAL
    {
        public DataTable ValidateUser(string username, string password)
        {
            string query = @"SELECT UserId, Name, Username, Role, IsActive 
                             FROM Users 
                             WHERE Username = @Username AND PasswordHash = @Password AND IsActive = 1;";
            
            var parameters = new[]
            {
                new MySqlParameter("@Username", username),
                new MySqlParameter("@Password", password)
            };

            return DbHelper.ExecuteDataTable(query, parameters);
        }
    }
}
```

### 5.1.4 `ProductDAL.cs`
**File Path:** `ShopManagement.DataAccess/ProductDAL.cs`

```csharp
using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class ProductDAL
    {
        public DataTable GetAllProducts(bool activeOnly = true)
        {
            string query = activeOnly
                ? "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate, UpdatedDate FROM Products WHERE IsActive = 1 ORDER BY ProductId DESC;"
                : "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate, UpdatedDate FROM Products ORDER BY ProductId DESC;";
            return DbHelper.ExecuteDataTable(query);
        }

        public DataTable GetProductById(int productId)
        {
            string query = "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive FROM Products WHERE ProductId = @ProductId;";
            return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@ProductId", productId) });
        }

        public DataTable CheckProductExists(string productCode, string productName)
        {
            string query = "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath FROM Products WHERE ProductCode = @ProductCode OR LOWER(ProductName) = LOWER(@ProductName) LIMIT 1;";
            var parameters = new[]
            {
                new MySqlParameter("@ProductCode", productCode ?? string.Empty),
                new MySqlParameter("@ProductName", productName ?? string.Empty)
            };
            return DbHelper.ExecuteDataTable(query, parameters);
        }

        // Upsert: insert or increment stock if product already exists
        public bool UpsertProduct(string productCode, string productName, int quantity, decimal price, string imagePath, out string operation)
        {
            var dtExisting = CheckProductExists(productCode, productName);

            if (dtExisting != null && dtExisting.Rows.Count > 0)
            {
                int existingId = Convert.ToInt32(dtExisting.Rows[0]["ProductId"]);
                string existingImage = Convert.ToString(dtExisting.Rows[0]["ImagePath"]);

                string resolvedImage = string.IsNullOrWhiteSpace(imagePath) ? existingImage : imagePath;

                string updateQuery = @"
                    UPDATE Products 
                    SET ProductName  = @ProductName,
                        Quantity     = Quantity + @Quantity,
                        Price        = @Price,
                        ImagePath    = @ImagePath,
                        IsActive     = 1,
                        UpdatedDate  = NOW()
                    WHERE ProductId  = @ProductId;";

                var updateParams = new[]
                {
                    new MySqlParameter("@ProductId",   existingId),
                    new MySqlParameter("@ProductName", productName),
                    new MySqlParameter("@Quantity",    quantity),
                    new MySqlParameter("@Price",       price),
                    new MySqlParameter("@ImagePath",   resolvedImage ?? "/images/products/default-product.svg")
                };

                int rows = DbHelper.ExecuteNonQuery(updateQuery, updateParams);
                operation = "Updated (Stock Incremented)";
                return rows > 0;
            }
            else
            {
                string defaultImage = string.IsNullOrWhiteSpace(imagePath)
                    ? "/images/products/default-product.svg"
                    : imagePath;

                string insertQuery = @"
                    INSERT INTO Products (ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate)
                    VALUES (@ProductCode, @ProductName, @Quantity, @Price, @ImagePath, 1, NOW());";

                var insertParams = new[]
                {
                    new MySqlParameter("@ProductCode", productCode),
                    new MySqlParameter("@ProductName", productName),
                    new MySqlParameter("@Quantity",    quantity),
                    new MySqlParameter("@Price",       price),
                    new MySqlParameter("@ImagePath",   defaultImage)
                };

                int rows = DbHelper.ExecuteNonQuery(insertQuery, insertParams);
                operation = "Created New Product";
                return rows > 0;
            }
        }

        // Edit existing product (sets exact quantity)
        public bool UpdateProduct(int productId, string productName, int quantity, decimal price, string newImagePath, out string errorMessage)
        {
            errorMessage = string.Empty;
            try
            {
                string query;
                MySqlParameter[] parameters;

                if (string.IsNullOrWhiteSpace(newImagePath))
                {
                    query = @"UPDATE Products
                              SET ProductName  = @ProductName,
                                  Quantity     = @Quantity,
                                  Price        = @Price,
                                  UpdatedDate  = NOW()
                              WHERE ProductId  = @ProductId;";
                    parameters = new[]
                    {
                        new MySqlParameter("@ProductId",   productId),
                        new MySqlParameter("@ProductName", productName),
                        new MySqlParameter("@Quantity",    quantity),
                        new MySqlParameter("@Price",       price)
                    };
                }
                else
                {
                    query = @"UPDATE Products
                              SET ProductName  = @ProductName,
                                  Quantity     = @Quantity,
                                  Price        = @Price,
                                  ImagePath    = @ImagePath,
                                  UpdatedDate  = NOW()
                              WHERE ProductId  = @ProductId;";
                    parameters = new[]
                    {
                        new MySqlParameter("@ProductId",   productId),
                        new MySqlParameter("@ProductName", productName),
                        new MySqlParameter("@Quantity",    quantity),
                        new MySqlParameter("@Price",       price),
                        new MySqlParameter("@ImagePath",   newImagePath)
                    };
                }

                return DbHelper.ExecuteNonQuery(query, parameters) > 0;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        public bool DeleteProduct(int productId)
        {
            string query = "UPDATE Products SET IsActive = 0, UpdatedDate = NOW() WHERE ProductId = @ProductId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@ProductId", productId) }) > 0;
        }

        public DataTable SearchAvailableProducts(string term)
        {
            string query = @"SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath
                             FROM Products
                             WHERE IsActive = 1 AND Quantity > 0
                               AND (ProductName LIKE @Term OR ProductCode LIKE @Term)
                             ORDER BY ProductName ASC;";
            return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@Term", "%" + (term ?? "") + "%") });
        }
    }
}
```

### 5.1.5 `StoreDAL.cs`
**File Path:** `ShopManagement.DataAccess/StoreDAL.cs`

```csharp
using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class StoreDAL
    {
        public DataTable GetAllStores(bool activeOnly = false)
        {
            string query = activeOnly
                ? @"SELECT StoreId, StoreCode, StoreName, Address, Phone, Email, IsActive, CreatedDate
                    FROM Stores WHERE IsActive = 1 ORDER BY StoreName ASC;"
                : @"SELECT StoreId, StoreCode, StoreName, Address, Phone, Email, IsActive, CreatedDate
                    FROM Stores ORDER BY StoreId DESC;";
            return DbHelper.ExecuteDataTable(query);
        }

        public DataTable GetStoreById(int storeId)
        {
            string query = @"SELECT StoreId, StoreCode, StoreName, Address, Phone, Email, IsActive 
                             FROM Stores WHERE StoreId = @StoreId;";
            return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@StoreId", storeId) });
        }

        public bool CreateStore(string storeCode, string storeName, string address, string phone, string email, out string errorMessage)
        {
            errorMessage = string.Empty;
            try
            {
                string query = @"INSERT INTO Stores (StoreCode, StoreName, Address, Phone, Email, IsActive, CreatedDate)
                                 VALUES (@StoreCode, @StoreName, @Address, @Phone, @Email, 1, NOW());";
                var parameters = new[]
                {
                    new MySqlParameter("@StoreCode", storeCode),
                    new MySqlParameter("@StoreName", storeName),
                    new MySqlParameter("@Address", string.IsNullOrWhiteSpace(address) ? (object)DBNull.Value : address),
                    new MySqlParameter("@Phone", string.IsNullOrWhiteSpace(phone) ? (object)DBNull.Value : phone),
                    new MySqlParameter("@Email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email)
                };
                return DbHelper.ExecuteNonQuery(query, parameters) > 0;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message.Contains("Duplicate") ? "Store code already exists." : ex.Message;
                return false;
            }
        }

        public bool UpdateStore(int storeId, string storeName, string address, string phone, string email, bool isActive)
        {
            string query = @"UPDATE Stores SET StoreName = @StoreName, Address = @Address, Phone = @Phone,
                             Email = @Email, IsActive = @IsActive, UpdatedDate = NOW()
                             WHERE StoreId = @StoreId;";
            var parameters = new[]
            {
                new MySqlParameter("@StoreId", storeId),
                new MySqlParameter("@StoreName", storeName),
                new MySqlParameter("@Address", string.IsNullOrWhiteSpace(address) ? (object)DBNull.Value : address),
                new MySqlParameter("@Phone", string.IsNullOrWhiteSpace(phone) ? (object)DBNull.Value : phone),
                new MySqlParameter("@Email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email),
                new MySqlParameter("@IsActive", isActive ? 1 : 0)
            };
            return DbHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        public bool DeleteStore(int storeId)
        {
            string query = "UPDATE Stores SET IsActive = 0, UpdatedDate = NOW() WHERE StoreId = @StoreId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@StoreId", storeId) }) > 0;
        }

        public DataTable GetStoreStats()
        {
            string query = @"
                SELECT 
                    s.StoreId, s.StoreName, s.StoreCode, s.IsActive,
                    COUNT(DISTINCT u.UserId) AS TotalEmployees,
                    COUNT(DISTINCT i.InvoiceId) AS TotalInvoices,
                    COALESCE(SUM(i.TotalAmount), 0) AS TotalRevenue
                FROM Stores s
                LEFT JOIN Users u ON u.StoreId = s.StoreId AND u.Role = 'Employee' AND u.IsActive = 1
                LEFT JOIN Invoices i ON i.StoreId = s.StoreId
                GROUP BY s.StoreId, s.StoreName, s.StoreCode, s.IsActive
                ORDER BY s.StoreId ASC;";
            return DbHelper.ExecuteDataTable(query);
        }
    }
}
```

### 5.1.6 `EmployeeDAL.cs`
**File Path:** `ShopManagement.DataAccess/EmployeeDAL.cs`

```csharp
using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class EmployeeDAL
    {
        public DataTable GetAllEmployees()
        {
            string query = @"SELECT u.UserId, u.Name, u.Username, u.Role, u.IsActive, u.CreatedDate,
                                    u.StoreId, COALESCE(s.StoreName, 'Main Branch') AS StoreName
                             FROM Users u
                             LEFT JOIN Stores s ON s.StoreId = u.StoreId
                             WHERE u.Role = 'Employee'
                             ORDER BY u.UserId DESC;";
            return DbHelper.ExecuteDataTable(query);
        }

        public DataTable GetEmployeeById(int userId)
        {
            string query = @"SELECT u.UserId, u.Name, u.Username, u.Role, u.IsActive, u.StoreId,
                                    COALESCE(s.StoreName, 'Main Branch') AS StoreName
                             FROM Users u
                             LEFT JOIN Stores s ON s.StoreId = u.StoreId
                             WHERE u.UserId = @UserId;";
            return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@UserId", userId) });
        }

        public bool CreateEmployee(string name, string username, string password, int? storeId)
        {
            string query = @"INSERT INTO Users (Name, Username, PasswordHash, Role, StoreId, IsActive, CreatedDate)
                             VALUES (@Name, @Username, @Password, 'Employee', @StoreId, 1, NOW());";
            var parameters = new[]
            {
                new MySqlParameter("@Name",     name),
                new MySqlParameter("@Username", username),
                new MySqlParameter("@Password", password),
                new MySqlParameter("@StoreId",  storeId.HasValue ? (object)storeId.Value : DBNull.Value)
            };
            return DbHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        public bool UpdateEmployee(int userId, string name, string password, bool isActive, int? storeId)
        {
            string query;
            MySqlParameter[] parameters;

            if (string.IsNullOrWhiteSpace(password))
            {
                query = @"UPDATE Users SET Name = @Name, IsActive = @IsActive, StoreId = @StoreId,
                          UpdatedDate = NOW() WHERE UserId = @UserId;";
                parameters = new[]
                {
                    new MySqlParameter("@UserId",  userId),
                    new MySqlParameter("@Name",    name),
                    new MySqlParameter("@IsActive",isActive ? 1 : 0),
                    new MySqlParameter("@StoreId", storeId.HasValue ? (object)storeId.Value : DBNull.Value)
                };
            }
            else
            {
                query = @"UPDATE Users SET Name = @Name, PasswordHash = @Password, IsActive = @IsActive,
                          StoreId = @StoreId, UpdatedDate = NOW() WHERE UserId = @UserId;";
                parameters = new[]
                {
                    new MySqlParameter("@UserId",   userId),
                    new MySqlParameter("@Name",     name),
                    new MySqlParameter("@Password", password),
                    new MySqlParameter("@IsActive", isActive ? 1 : 0),
                    new MySqlParameter("@StoreId",  storeId.HasValue ? (object)storeId.Value : DBNull.Value)
                };
            }

            return DbHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        public bool ResetPassword(int userId, string newPassword)
        {
            string query = "UPDATE Users SET PasswordHash = @Password, UpdatedDate = NOW() WHERE UserId = @UserId;";
            var parameters = new[]
            {
                new MySqlParameter("@UserId", userId),
                new MySqlParameter("@Password", newPassword)
            };
            return DbHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        public bool ToggleStatus(int userId)
        {
            string query = "UPDATE Users SET IsActive = CASE WHEN IsActive = 1 THEN 0 ELSE 1 END, UpdatedDate = NOW() WHERE UserId = @UserId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@UserId", userId) }) > 0;
        }

        public bool DeleteEmployee(int userId)
        {
            string query = "UPDATE Users SET IsActive = 0, UpdatedDate = NOW() WHERE UserId = @UserId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@UserId", userId) }) > 0;
        }
    }
}
```

### 5.1.7 `InvoiceDAL.cs`
**File Path:** `ShopManagement.DataAccess/InvoiceDAL.cs`  
**Role:** Coordinates ACID transactions: checks product stock availability, locks product rows (`FOR UPDATE`), writes Invoice header, inserts details, and decrements inventory quantity.

```csharp
using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class InvoiceDAL
    {
        public bool CreateInvoice(string customerName, string customerPhone, int createdBy, DataTable items, out string invoiceNo, out string errorMessage)
        {
            invoiceNo = "INV-" + DateTime.Now.ToString("yyyyMMddHHmmss");
            errorMessage = string.Empty;

            using (var conn = DbHelper.GetConnection())
            using (var trans = conn.BeginTransaction())
            {
                try
                {
                    decimal grandTotal = 0;

                    // 1. Validate items and stock availability first
                    foreach (DataRow row in items.Rows)
                    {
                        int productId = Convert.ToInt32(row["ProductId"]);
                        int qty = Convert.ToInt32(row["Quantity"]);
                        decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                        decimal lineTotal = qty * unitPrice;
                        grandTotal += lineTotal;

                        string checkStockQuery = "SELECT ProductName, Quantity FROM Products WHERE ProductId = @ProductId FOR UPDATE;";
                        using (var checkCmd = new MySqlCommand(checkStockQuery, conn, trans))
                        {
                            checkCmd.Parameters.AddWithValue("@ProductId", productId);
                            using (var reader = checkCmd.ExecuteReader())
                            {
                                if (!reader.Read())
                                {
                                    reader.Close();
                                    errorMessage = $"Product ID {productId} does not exist.";
                                    trans.Rollback();
                                    return false;
                                }

                                string prodName = reader.GetString("ProductName");
                                int currentStock = reader.GetInt32("Quantity");
                                reader.Close();

                                if (currentStock < qty)
                                {
                                    errorMessage = $"Insufficient stock for '{prodName}'. Available: {currentStock}, Requested: {qty}.";
                                    trans.Rollback();
                                    return false;
                                }
                            }
                        }
                    }

                    // 2. Insert Invoice Header
                    string insertInvoiceQuery = @"
                        INSERT INTO Invoices (InvoiceNo, CustomerName, CustomerPhone, CreatedBy, InvoiceDate, TotalAmount)
                        VALUES (@InvoiceNo, @CustomerName, @CustomerPhone, @CreatedBy, NOW(), @TotalAmount);
                        SELECT LAST_INSERT_ID();";

                    int invoiceId;
                    using (var invCmd = new MySqlCommand(insertInvoiceQuery, conn, trans))
                    {
                        invCmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo);
                        invCmd.Parameters.AddWithValue("@CustomerName", customerName);
                        invCmd.Parameters.AddWithValue("@CustomerPhone", string.IsNullOrWhiteSpace(customerPhone) ? (object)DBNull.Value : customerPhone);
                        invCmd.Parameters.AddWithValue("@CreatedBy", createdBy);
                        invCmd.Parameters.AddWithValue("@TotalAmount", grandTotal);

                        invoiceId = Convert.ToInt32(invCmd.ExecuteScalar());
                    }

                    // 3. Insert Invoice Details and Deduct Stock
                    foreach (DataRow row in items.Rows)
                    {
                        int productId = Convert.ToInt32(row["ProductId"]);
                        string prodName = Convert.ToString(row["ProductName"]);
                        int qty = Convert.ToInt32(row["Quantity"]);
                        decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                        decimal lineTotal = qty * unitPrice;

                        // Insert detail
                        string insertDetailQuery = @"
                            INSERT INTO InvoiceDetails (InvoiceId, ProductId, ProductName, Quantity, UnitPrice, TotalAmount)
                            VALUES (@InvoiceId, @ProductId, @ProductName, @Quantity, @UnitPrice, @TotalAmount);";

                        using (var detCmd = new MySqlCommand(insertDetailQuery, conn, trans))
                        {
                            detCmd.Parameters.AddWithValue("@InvoiceId", invoiceId);
                            detCmd.Parameters.AddWithValue("@ProductId", productId);
                            detCmd.Parameters.AddWithValue("@ProductName", prodName);
                            detCmd.Parameters.AddWithValue("@Quantity", qty);
                            detCmd.Parameters.AddWithValue("@UnitPrice", unitPrice);
                            detCmd.Parameters.AddWithValue("@TotalAmount", lineTotal);
                            detCmd.ExecuteNonQuery();
                        }

                        // Deduct stock from products table
                        string deductStockQuery = @"
                            UPDATE Products 
                            SET Quantity = Quantity - @Quantity, 
                                UpdatedDate = NOW() 
                            WHERE ProductId = @ProductId;";

                        using (var stockCmd = new MySqlCommand(deductStockQuery, conn, trans))
                        {
                            stockCmd.Parameters.AddWithValue("@Quantity", qty);
                            stockCmd.Parameters.AddWithValue("@ProductId", productId);
                            stockCmd.ExecuteNonQuery();
                        }
                    }

                    trans.Commit();
                    return true;
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    errorMessage = ex.Message;
                    return false;
                }
            }
        }

        public DataTable GetInvoiceHistory(int? createdBy = null)
        {
            string query = @"
                SELECT 
                    i.InvoiceId, 
                    i.InvoiceNo, 
                    i.CustomerName, 
                    i.CustomerPhone, 
                    i.TotalAmount, 
                    i.InvoiceDate,
                    u.Name AS CreatedByName,
                    u.Role AS CreatedByRole
                FROM Invoices i
                INNER JOIN Users u ON i.CreatedBy = u.UserId " +
                (createdBy.HasValue ? "WHERE i.CreatedBy = @CreatedBy " : "") +
                "ORDER BY i.InvoiceId DESC;";

            var parameters = createdBy.HasValue 
                ? new[] { new MySqlParameter("@CreatedBy", createdBy.Value) } 
                : null;

            return DbHelper.ExecuteDataTable(query, parameters);
        }

        public DataTable GetInvoiceHeader(int invoiceId)
        {
            string query = @"
                SELECT 
                    i.InvoiceId, 
                    i.InvoiceNo, 
                    i.CustomerName, 
                    i.CustomerPhone, 
                    i.TotalAmount, 
                    i.InvoiceDate,
                    u.Name AS CreatedByName,
                    u.Username AS CreatedByUsername
                FROM Invoices i
                INNER JOIN Users u ON i.CreatedBy = u.UserId
                WHERE i.InvoiceId = @InvoiceId;";

            var parameters = new[] { new MySqlParameter("@InvoiceId", invoiceId) };
            return DbHelper.ExecuteDataTable(query, parameters);
        }

        public DataTable GetInvoiceDetails(int invoiceId)
        {
            string query = @"
                SELECT 
                    d.InvoiceDetailId, 
                    d.InvoiceId, 
                    d.ProductId, 
                    d.ProductName, 
                    d.Quantity, 
                    d.UnitPrice, 
                    d.TotalAmount,
                    p.ProductCode,
                    p.ImagePath
                FROM InvoiceDetails d
                LEFT JOIN Products p ON d.ProductId = p.ProductId
                WHERE d.InvoiceId = @InvoiceId;";

            var parameters = new[] { new MySqlParameter("@InvoiceId", invoiceId) };
            return DbHelper.ExecuteDataTable(query, parameters);
        }

        public DataTable GetDashboardMetrics()
        {
            string query = @"
                SELECT 
                    (SELECT COUNT(*) FROM Products WHERE IsActive = 1) AS TotalProducts,
                    (SELECT COUNT(*) FROM Products WHERE IsActive = 1 AND Quantity <= 10) AS LowStockProducts,
                    (SELECT COUNT(*) FROM Invoices) AS TotalInvoices,
                    (SELECT COALESCE(SUM(TotalAmount), 0) FROM Invoices) AS TotalRevenue,
                    (SELECT COUNT(*) FROM Users WHERE Role = 'Employee' AND IsActive = 1) AS TotalEmployees;";

            return DbHelper.ExecuteDataTable(query);
        }
    }
}
```

---

## 5.2 Business Access Layer (`ShopManagement.Business`)

### 5.2.1 `ShopManagement.Business.csproj`
```xml
<Project Sdk="Microsoft.NET.Sdk">

  <ItemGroup>
    <ProjectReference Include="..\ShopManagement.DataAccess\ShopManagement.DataAccess.csproj" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="ClosedXML" Version="0.105.1" />
  </ItemGroup>

  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
  </PropertyGroup>

</Project>
```

### 5.2.2 `AccountBAL.cs`
**File Path:** `ShopManagement.Business/AccountBAL.cs`

```csharp
using System;
using System.Data;
using ShopManagement.DataAccess;

namespace ShopManagement.Business
{
    public class AccountBAL
    {
        private readonly AccountDAL _dal = new AccountDAL();

        public DataTable Login(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return new DataTable();
            }

            return _dal.ValidateUser(username.Trim(), password.Trim());
        }
    }
}
```

### 5.2.3 `ProductBAL.cs`
**File Path:** `ShopManagement.Business/ProductBAL.cs`

```csharp
using System;
using System.Data;
using ShopManagement.DataAccess;

namespace ShopManagement.Business
{
    public class ProductBAL
    {
        private readonly ProductDAL _dal = new ProductDAL();

        public DataTable GetAllProducts(bool activeOnly = true)
        {
            return _dal.GetAllProducts(activeOnly);
        }

        public DataTable GetProductById(int productId)
        {
            return _dal.GetProductById(productId);
        }

        public bool UpsertProduct(string productCode, string productName, int quantity, decimal price, string imagePath, out string operation)
        {
            if (string.IsNullOrWhiteSpace(productCode) || string.IsNullOrWhiteSpace(productName))
            {
                operation = "Product code and name are required.";
                return false;
            }

            if (quantity < 0) quantity = 0;
            if (price < 0) price = 0;

            return _dal.UpsertProduct(productCode.Trim(), productName.Trim(), quantity, price, imagePath, out operation);
        }

        public bool UpdateProduct(int productId, string productName, int quantity, decimal price, string newImagePath, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(productName))
            {
                errorMessage = "Product Name is required.";
                return false;
            }

            if (quantity < 0) quantity = 0;
            if (price < 0) price = 0;

            return _dal.UpdateProduct(productId, productName.Trim(), quantity, price, newImagePath, out errorMessage);
        }

        public bool DeleteProduct(int productId)
        {
            return _dal.DeleteProduct(productId);
        }

        public DataTable SearchAvailableProducts(string term)
        {
            return _dal.SearchAvailableProducts(term);
        }
    }
}
```

### 5.2.4 `StoreBAL.cs`
**File Path:** `ShopManagement.Business/StoreBAL.cs`

```csharp
using System;
using System.Data;
using ShopManagement.DataAccess;

namespace ShopManagement.Business
{
    public class StoreBAL
    {
        private readonly StoreDAL _dal = new StoreDAL();

        public DataTable GetAllStores(bool activeOnly = false)
        {
            return _dal.GetAllStores(activeOnly);
        }

        public DataTable GetStoreById(int storeId)
        {
            return _dal.GetStoreById(storeId);
        }

        public DataTable GetStoreStats()
        {
            return _dal.GetStoreStats();
        }

        public bool CreateStore(string storeCode, string storeName, string address, string phone, string email, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(storeCode) || string.IsNullOrWhiteSpace(storeName))
            {
                errorMessage = "Store Code and Store Name are required.";
                return false;
            }

            return _dal.CreateStore(storeCode.Trim().ToUpper(), storeName.Trim(), address, phone, email, out errorMessage);
        }

        public bool UpdateStore(int storeId, string storeName, string address, string phone, string email, bool isActive, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(storeName))
            {
                errorMessage = "Store Name is required.";
                return false;
            }

            return _dal.UpdateStore(storeId, storeName.Trim(), address, phone, email, isActive);
        }

        public bool DeleteStore(int storeId)
        {
            return _dal.DeleteStore(storeId);
        }
    }
}
```

### 5.2.5 `EmployeeBAL.cs`
**File Path:** `ShopManagement.Business/EmployeeBAL.cs`

```csharp
using System;
using System.Data;
using ShopManagement.DataAccess;

namespace ShopManagement.Business
{
    public class EmployeeBAL
    {
        private readonly EmployeeDAL _dal = new EmployeeDAL();

        public DataTable GetAllEmployees()
        {
            return _dal.GetAllEmployees();
        }

        public DataTable GetEmployeeById(int userId)
        {
            return _dal.GetEmployeeById(userId);
        }

        public bool CreateEmployee(string name, string username, string password, int? storeId, out string errorMessage)
        {
            errorMessage = string.Empty;
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "All fields (Name, Username, Password) are required.";
                return false;
            }

            try
            {
                return _dal.CreateEmployee(name.Trim(), username.Trim(), password.Trim(), storeId);
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message.Contains("Duplicate") || ex.Message.Contains("UNIQUE")
                    ? "Username already exists. Please choose a different username."
                    : ex.Message;
                return false;
            }
        }

        public bool UpdateEmployee(int userId, string name, string password, bool isActive, int? storeId, out string errorMessage)
        {
            errorMessage = string.Empty;
            if (string.IsNullOrWhiteSpace(name))
            {
                errorMessage = "Name is required.";
                return false;
            }

            try
            {
                return _dal.UpdateEmployee(userId, name.Trim(), password?.Trim(), isActive, storeId);
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        public bool ResetPassword(int userId, string newPassword, out string errorMessage)
        {
            errorMessage = string.Empty;
            if (string.IsNullOrWhiteSpace(newPassword))
            {
                errorMessage = "New password cannot be empty.";
                return false;
            }

            try
            {
                return _dal.ResetPassword(userId, newPassword.Trim());
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        public bool ToggleStatus(int userId)
        {
            return _dal.ToggleStatus(userId);
        }

        public bool DeleteEmployee(int userId)
        {
            return _dal.DeleteEmployee(userId);
        }
    }
}
```

### 5.2.6 `InvoiceBAL.cs`
**File Path:** `ShopManagement.Business/InvoiceBAL.cs`

```csharp
using System;
using System.Data;
using ShopManagement.DataAccess;

namespace ShopManagement.Business
{
    public class InvoiceBAL
    {
        private readonly InvoiceDAL _dal = new InvoiceDAL();

        public bool CreateInvoice(string customerName, string customerPhone, int createdBy, DataTable items, out string invoiceNo, out string errorMessage)
        {
            invoiceNo = string.Empty;
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(customerName))
            {
                errorMessage = "Customer Name is required.";
                return false;
            }

            if (items == null || items.Rows.Count == 0)
            {
                errorMessage = "Invoice must contain at least one product item.";
                return false;
            }

            return _dal.CreateInvoice(customerName.Trim(), customerPhone?.Trim(), createdBy, items, out invoiceNo, out errorMessage);
        }

        public DataTable GetInvoiceHistory(int? createdBy = null)
        {
            return _dal.GetInvoiceHistory(createdBy);
        }

        public DataTable GetInvoiceHeader(int invoiceId)
        {
            return _dal.GetInvoiceHeader(invoiceId);
        }

        public DataTable GetInvoiceDetails(int invoiceId)
        {
            return _dal.GetInvoiceDetails(invoiceId);
        }

        public DataTable GetDashboardMetrics()
        {
            return _dal.GetDashboardMetrics();
        }
    }
}
```

### 5.2.7 `ExcelBAL.cs`
**File Path:** `ShopManagement.Business/ExcelBAL.cs`  
**Role:** Streams uploaded Excel files, parses worksheets row-by-row, calls Upsert for each product, and builds Excel template files using ClosedXML.

```csharp
using System;
using System.Data;
using System.IO;
using ClosedXML.Excel;

namespace ShopManagement.Business
{
    public class ExcelBAL
    {
        private readonly ProductBAL _productBAL = new ProductBAL();

        public DataTable ProcessExcelProductImport(Stream fileStream, out int totalCount, out int insertedCount, out int updatedCount, out int failedCount)
        {
            totalCount = 0;
            insertedCount = 0;
            updatedCount = 0;
            failedCount = 0;

            var resultDt = new DataTable("ImportResults");
            resultDt.Columns.Add("RowNumber", typeof(int));
            resultDt.Columns.Add("ProductCode", typeof(string));
            resultDt.Columns.Add("ProductName", typeof(string));
            resultDt.Columns.Add("Quantity", typeof(int));
            resultDt.Columns.Add("Price", typeof(decimal));
            resultDt.Columns.Add("Status", typeof(string));
            resultDt.Columns.Add("Message", typeof(string));

            using (var workbook = new XLWorkbook(fileStream))
            {
                var worksheet = workbook.Worksheet(1);
                var rows = worksheet.RangeUsed().RowsUsed();

                bool isFirstRow = true;
                int rowNum = 1;

                foreach (var row in rows)
                {
                    if (isFirstRow)
                    {
                        isFirstRow = false;
                        rowNum++;
                        continue;
                    }

                    totalCount++;
                    string productCode = row.Cell(1).GetString()?.Trim();
                    string productName = row.Cell(2).GetString()?.Trim();
                    string qtyStr = row.Cell(3).GetString()?.Trim();
                    string priceStr = row.Cell(4).GetString()?.Trim();
                    string imagePath = row.Cell(5).GetString()?.Trim();

                    if (string.IsNullOrWhiteSpace(productCode) && string.IsNullOrWhiteSpace(productName))
                    {
                        continue;
                    }

                    int qty = 0;
                    decimal price = 0;
                    bool isQtyValid = int.TryParse(qtyStr, out qty);
                    bool isPriceValid = decimal.TryParse(priceStr, out price);

                    if (string.IsNullOrWhiteSpace(productCode) || string.IsNullOrWhiteSpace(productName) || !isQtyValid || !isPriceValid)
                    {
                        failedCount++;
                        resultDt.Rows.Add(rowNum, productCode, productName, qty, price, "Failed", "Invalid data format or missing required fields.");
                        rowNum++;
                        continue;
                    }

                    string operation;
                    bool success = _productBAL.UpsertProduct(productCode, productName, qty, price, imagePath, out operation);

                    if (success)
                    {
                        if (operation.Contains("Updated"))
                            updatedCount++;
                        else
                            insertedCount++;

                        resultDt.Rows.Add(rowNum, productCode, productName, qty, price, "Success", operation);
                    }
                    else
                    {
                        failedCount++;
                        resultDt.Rows.Add(rowNum, productCode, productName, qty, price, "Failed", operation);
                    }

                    rowNum++;
                }
            }

            return resultDt;
        }

        public byte[] GenerateSampleExcelTemplate()
        {
            using (var workbook = new XLWorkbook())
            {
                var ws = workbook.Worksheets.Add("Products");

                ws.Cell(1, 1).Value = "ProductCode";
                ws.Cell(1, 2).Value = "ProductName";
                ws.Cell(1, 3).Value = "Quantity";
                ws.Cell(1, 4).Value = "Price";
                ws.Cell(1, 5).Value = "ImagePath";

                var headerRange = ws.Range("A1:E1");
                headerRange.Style.Font.Bold = true;
                headerRange.Style.Fill.BackgroundColor = XLColor.FromHtml("#2563EB");
                headerRange.Style.Font.FontColor = XLColor.White;

                ws.Cell(2, 1).Value = "P101";
                ws.Cell(2, 2).Value = "Wireless Optical Mouse";
                ws.Cell(2, 3).Value = 25;
                ws.Cell(2, 4).Value = 499.00;
                ws.Cell(2, 5).Value = "/images/products/default-product.svg";

                ws.Columns().AdjustToContents();

                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    return ms.ToArray();
                }
            }
        }
    }
}
```

---

## 5.3 Web Presentation Layer (`ShopManagement.Web`)

### 5.3.1 `ShopManagement.Web.csproj`
```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <ItemGroup>
    <ProjectReference Include="..\ShopManagement.Business\ShopManagement.Business.csproj" />
    <ProjectReference Include="..\ShopManagement.DataAccess\ShopManagement.DataAccess.csproj" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="Newtonsoft.Json" Version="13.0.4" />
  </ItemGroup>

  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>

</Project>
```

### 5.3.2 `appsettings.json`
**File Path:** `ShopManagement.Web/appsettings.json`

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=ShopManagementDB;User ID=root;Password=root;Port=3306;AllowUserVariables=True;"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

### 5.3.3 `Program.cs`
**File Path:** `ShopManagement.Web/Program.cs`

```csharp
using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ShopManagement.DataAccess;

var builder = WebApplication.CreateBuilder(args);

// 1. Configure Database Connection String into DbHelper
string connectionString = builder.Configuration.GetConnectionString("DefaultConnection") 
    ?? "Server=localhost;Database=ShopManagementDB;User ID=root;Password=root;Port=3306;AllowUserVariables=True;";
DbHelper.ConnectionString = connectionString;

// 2. Add services
builder.Services.AddControllersWithViews();
builder.Services.AddHttpContextAccessor();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(4);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Account/Login");
}

// 3. Auto initialize database tables & defaults
try
{
    DbHelper.InitializeDatabase();
}
catch (Exception ex)
{
    Console.WriteLine($"DB Initialization note: {ex.Message}");
}

app.UseStaticFiles();
app.UseRouting();

app.UseSession();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();
```

### 5.3.4 `AccountController.cs`
**File Path:** `ShopManagement.Web/Controllers/AccountController.cs`

```csharp
using System;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopManagement.Business;

namespace ShopManagement.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly AccountBAL _accountBAL = new AccountBAL();

        [HttpGet]
        public IActionResult Login()
        {
            string? role = HttpContext.Session.GetString("Role");
            if (!string.IsNullOrEmpty(role))
            {
                return role.Equals("Admin", StringComparison.OrdinalIgnoreCase) 
                    ? RedirectToAction("Index", "Product") 
                    : RedirectToAction("Create", "Invoice");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ViewBag.Error = "Please enter both username and password.";
                return View();
            }

            DataTable dt = _accountBAL.Login(username, password);

            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                int userId = Convert.ToInt32(row["UserId"]);
                string fullName = Convert.ToString(row["Name"]) ?? "";
                string user = Convert.ToString(row["Username"]) ?? "";
                string role = Convert.ToString(row["Role"]) ?? "";

                HttpContext.Session.SetInt32("UserId", userId);
                HttpContext.Session.SetString("Username", user);
                HttpContext.Session.SetString("FullName", fullName);
                HttpContext.Session.SetString("Role", role);

                if (role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                {
                    return RedirectToAction("Index", "Product");
                }
                else
                {
                    return RedirectToAction("Create", "Invoice");
                }
            }

            ViewBag.Error = "Invalid credentials or account is inactive.";
            return View();
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
```

### 5.3.5 `DashboardController.cs`
**File Path:** `ShopManagement.Web/Controllers/DashboardController.cs`

```csharp
using System;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopManagement.Business;

namespace ShopManagement.Web.Controllers
{
    public class DashboardController : Controller
    {
        private readonly InvoiceBAL _invoiceBAL = new InvoiceBAL();

        [HttpGet]
        public IActionResult Index()
        {
            string? role = HttpContext.Session.GetString("Role");
            if (string.IsNullOrEmpty(role)) return RedirectToAction("Login", "Account");
            if (!role.Equals("Admin", StringComparison.OrdinalIgnoreCase)) return RedirectToAction("Create", "Invoice");

            DataTable dtMetrics = _invoiceBAL.GetDashboardMetrics();
            return View(dtMetrics);
        }
    }
}
```

### 5.3.6 `ProductController.cs`
**File Path:** `ShopManagement.Web/Controllers/ProductController.cs`

```csharp
using System;
using System.Data;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ShopManagement.Business;

namespace ShopManagement.Web.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductBAL _productBAL = new ProductBAL();
        private readonly ExcelBAL _excelBAL = new ExcelBAL();
        private readonly IWebHostEnvironment _env;

        public ProductController(IWebHostEnvironment env)
        {
            _env = env;
        }

        private bool IsAdmin()
        {
            string? role = HttpContext.Session.GetString("Role");
            return !string.IsNullOrEmpty(role) && role.Equals("Admin", StringComparison.OrdinalIgnoreCase);
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpGet]
        public IActionResult GetProductsJson()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("Role")))
                return Unauthorized();

            DataTable dt = _productBAL.GetAllProducts(true);
            return Content(JsonConvert.SerializeObject(dt), "application/json");
        }

        [HttpGet]
        public IActionResult GetProductByIdJson(int id)
        {
            if (!IsAdmin()) return Unauthorized();
            DataTable dt = _productBAL.GetProductById(id);
            return Content(JsonConvert.SerializeObject(dt), "application/json");
        }

        [HttpGet]
        public IActionResult SearchAvailable(string term)
        {
            DataTable dt = _productBAL.SearchAvailableProducts(term);
            return Content(JsonConvert.SerializeObject(dt), "application/json");
        }

        [HttpPost]
        public IActionResult Add(string productCode, string productName, int quantity, decimal price, IFormFile? imageFile)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            if (string.IsNullOrWhiteSpace(productCode) || string.IsNullOrWhiteSpace(productName))
                return Json(new { success = false, message = "Product Code and Product Name are required." });

            string? imagePath = SaveUploadedImage(imageFile);

            string operation;
            bool success = _productBAL.UpsertProduct(productCode, productName, quantity, price, imagePath, out operation);

            return Json(new { success, message = operation });
        }

        [HttpPost]
        public IActionResult Edit(int productId, string productName, int quantity, decimal price, IFormFile? imageFile)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            if (string.IsNullOrWhiteSpace(productName))
                return Json(new { success = false, message = "Product Name is required." });

            string? newImagePath = SaveUploadedImage(imageFile);

            string errorMessage;
            bool success = _productBAL.UpdateProduct(productId, productName, quantity, price, newImagePath, out errorMessage);

            return Json(new { success, message = success ? "Product updated successfully!" : errorMessage });
        }

        [HttpPost]
        public IActionResult Delete(int productId)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            bool success = _productBAL.DeleteProduct(productId);
            return Json(new { success, message = success ? "Product deleted successfully." : "Error deleting product." });
        }

        [HttpGet]
        public IActionResult Import()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpPost]
        public IActionResult Import(IFormFile excelFile)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Account");

            if (excelFile == null || excelFile.Length == 0)
            {
                ViewBag.Error = "Please select a valid Excel file (.xlsx).";
                return View();
            }

            try
            {
                int total, inserted, updated, failed;
                using (var stream = excelFile.OpenReadStream())
                {
                    DataTable resultDt = _excelBAL.ProcessExcelProductImport(stream, out total, out inserted, out updated, out failed);

                    ViewBag.Total    = total;
                    ViewBag.Inserted = inserted;
                    ViewBag.Updated  = updated;
                    ViewBag.Failed   = failed;
                    ViewBag.Success  = true;

                    return View(resultDt);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Error parsing Excel: " + ex.Message;
                return View();
            }
        }

        [HttpGet]
        public IActionResult DownloadTemplate()
        {
            byte[] fileBytes = _excelBAL.GenerateSampleExcelTemplate();
            return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Products_Import_Template.xlsx");
        }

        private string? SaveUploadedImage(IFormFile? imageFile)
        {
            if (imageFile == null || imageFile.Length == 0) return null;

            string uploadFolder = Path.Combine(_env.WebRootPath, "uploads", "products");
            if (!Directory.Exists(uploadFolder))
                Directory.CreateDirectory(uploadFolder);

            string uniqueFileName = $"{Guid.NewGuid()}_{Path.GetFileName(imageFile.FileName)}";
            string filePath = Path.Combine(uploadFolder, uniqueFileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                imageFile.CopyTo(stream);
            }
            return $"/uploads/products/{uniqueFileName}";
        }
    }
}
```

### 5.3.7 `StoreController.cs`
**File Path:** `ShopManagement.Web/Controllers/StoreController.cs`

```csharp
using System;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ShopManagement.Business;

namespace ShopManagement.Web.Controllers
{
    public class StoreController : Controller
    {
        private readonly StoreBAL _storeBAL = new StoreBAL();

        private bool IsAdmin()
        {
            string? role = HttpContext.Session.GetString("Role");
            return !string.IsNullOrEmpty(role) && role.Equals("Admin", StringComparison.OrdinalIgnoreCase);
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpGet]
        public IActionResult GetStoresJson()
        {
            if (!IsAdmin()) return Unauthorized();
            DataTable dt = _storeBAL.GetAllStores(false);
            return Content(JsonConvert.SerializeObject(dt), "application/json");
        }

        [HttpPost]
        public IActionResult Create(string storeCode, string storeName, string address, string phone, string email)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            string errorMessage;
            bool success = _storeBAL.CreateStore(storeCode, storeName, address, phone, email, out errorMessage);

            return Json(new { success, message = success ? $"Store '{storeName}' created successfully!" : errorMessage });
        }

        [HttpPost]
        public IActionResult Update(int storeId, string storeName, string address, string phone, string email, bool isActive)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            string errorMessage;
            bool success = _storeBAL.UpdateStore(storeId, storeName, address, phone, email, isActive, out errorMessage);

            return Json(new { success, message = success ? "Store updated successfully!" : errorMessage });
        }

        [HttpPost]
        public IActionResult Delete(int storeId)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            bool success = _storeBAL.DeleteStore(storeId);
            return Json(new { success, message = success ? "Store deactivated." : "Error deactivating store." });
        }
    }
}
```

### 5.3.8 `EmployeeController.cs`
**File Path:** `ShopManagement.Web/Controllers/EmployeeController.cs`

```csharp
using System;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ShopManagement.Business;

namespace ShopManagement.Web.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeBAL _employeeBAL = new EmployeeBAL();
        private readonly StoreBAL _storeBAL = new StoreBAL();

        private bool IsAdmin()
        {
            string? role = HttpContext.Session.GetString("Role");
            return !string.IsNullOrEmpty(role) && role.Equals("Admin", StringComparison.OrdinalIgnoreCase);
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpGet]
        public IActionResult GetEmployeesJson()
        {
            if (!IsAdmin()) return Unauthorized();
            try
            {
                DataTable dt = _employeeBAL.GetAllEmployees();
                var list = new System.Collections.Generic.List<System.Collections.Generic.Dictionary<string, object?>>();
                foreach (DataRow r in dt.Rows)
                {
                    var d = new System.Collections.Generic.Dictionary<string, object?>();
                    foreach (DataColumn c in dt.Columns)
                    {
                        d[c.ColumnName] = r[c] == DBNull.Value ? null : r[c];
                    }
                    list.Add(d);
                }
                return Content(JsonConvert.SerializeObject(list), "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult Add(string name, string username, string password, int? storeId)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return Json(new { success = false, message = "Please enter Name, Username, and Password." });
            }

            string errorMessage;
            bool success = _employeeBAL.CreateEmployee(name.Trim(), username.Trim(), password.Trim(), storeId, out errorMessage);

            return Json(new { success, message = success ? $"Desk login for '{username.Trim()}' created successfully!" : errorMessage });
        }

        [HttpPost]
        public IActionResult Update(int userId, string name, string? password, bool isActive, int? storeId)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            string errorMessage;
            bool success = _employeeBAL.UpdateEmployee(userId, name, password, isActive, storeId, out errorMessage);
            return Json(new { success, message = success ? "Desk login updated successfully!" : errorMessage });
        }

        [HttpPost]
        public IActionResult ResetPassword(int userId, string newPassword)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            string errorMessage;
            bool success = _employeeBAL.ResetPassword(userId, newPassword, out errorMessage);
            return Json(new { success, message = success ? "Password changed successfully!" : errorMessage });
        }

        [HttpPost]
        public IActionResult ToggleStatus(int userId)
        {
            if (!IsAdmin()) return Json(new { success = false, message = "Unauthorized" });

            bool success = _employeeBAL.ToggleStatus(userId);
            return Json(new { success, message = success ? "Desk login status toggled successfully." : "Error toggling status." });
        }
    }
}
```

### 5.3.9 `InvoiceController.cs`
**File Path:** `ShopManagement.Web/Controllers/InvoiceController.cs`

```csharp
using System;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ShopManagement.Business;

namespace ShopManagement.Web.Controllers
{
    public class InvoiceController : Controller
    {
        private readonly InvoiceBAL _invoiceBAL = new InvoiceBAL();
        private readonly ProductBAL _productBAL = new ProductBAL();

        private bool IsLoggedIn()
        {
            return !string.IsNullOrEmpty(HttpContext.Session.GetString("Role"));
        }

        [HttpGet]
        public IActionResult Create()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpPost]
        public IActionResult Create(string customerName, string customerPhone, string itemsJson)
        {
            if (!IsLoggedIn()) return Json(new { success = false, message = "Session expired. Please log in again." });

            if (string.IsNullOrWhiteSpace(customerName))
            {
                return Json(new { success = false, message = "Customer name is required." });
            }

            if (string.IsNullOrWhiteSpace(itemsJson))
            {
                return Json(new { success = false, message = "Please select at least one product." });
            }

            try
            {
                var jArray = JArray.Parse(itemsJson);
                if (jArray.Count == 0)
                {
                    return Json(new { success = false, message = "Invoice must contain at least one product." });
                }

                var itemsDt = new DataTable("InvoiceItems");
                itemsDt.Columns.Add("ProductId", typeof(int));
                itemsDt.Columns.Add("ProductName", typeof(string));
                itemsDt.Columns.Add("Quantity", typeof(int));
                itemsDt.Columns.Add("UnitPrice", typeof(decimal));

                foreach (var item in jArray)
                {
                    int productId = item["productId"]?.Value<int>() ?? 0;
                    string productName = item["productName"]?.Value<string>() ?? "";
                    int qty = item["quantity"]?.Value<int>() ?? 0;
                    decimal unitPrice = item["unitPrice"]?.Value<decimal>() ?? 0;

                    if (productId <= 0 || qty <= 0)
                    {
                        return Json(new { success = false, message = "Invalid product or quantity in line items." });
                    }

                    itemsDt.Rows.Add(productId, productName, qty, unitPrice);
                }

                int createdBy = HttpContext.Session.GetInt32("UserId") ?? 1;
                string invoiceNo;
                string errorMessage;

                bool success = _invoiceBAL.CreateInvoice(customerName, customerPhone, createdBy, itemsDt, out invoiceNo, out errorMessage);

                if (success)
                {
                    return Json(new { success = true, invoiceNo = invoiceNo, message = $"Invoice {invoiceNo} generated successfully!" });
                }
                else
                {
                    return Json(new { success = false, message = errorMessage });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error creating invoice: " + ex.Message });
            }
        }

        [HttpGet]
        public IActionResult History()
        {
            if (!IsLoggedIn()) return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpGet]
        public IActionResult GetInvoicesJson()
        {
            if (!IsLoggedIn()) return Unauthorized();
            DataTable dt = _invoiceBAL.GetInvoiceHistory();
            return Content(JsonConvert.SerializeObject(dt), "application/json");
        }

        [HttpGet]
        public IActionResult GetInvoiceDetailsJson(int id)
        {
            if (!IsLoggedIn()) return Unauthorized();

            DataTable dtHeader = _invoiceBAL.GetInvoiceHeader(id);
            if (dtHeader == null || dtHeader.Rows.Count == 0)
            {
                return Content(JsonConvert.SerializeObject(new { success = false, message = "Invoice not found" }), "application/json");
            }

            DataTable dtDetails = _invoiceBAL.GetInvoiceDetails(id);

            var headerRows = new System.Collections.Generic.List<System.Collections.Generic.Dictionary<string, object?>>();
            foreach (DataRow r in dtHeader.Rows)
            {
                var dict = new System.Collections.Generic.Dictionary<string, object?>();
                foreach (DataColumn col in dtHeader.Columns)
                    dict[col.ColumnName] = r[col] == DBNull.Value ? null : r[col];
                headerRows.Add(dict);
            }

            var detailRows = new System.Collections.Generic.List<System.Collections.Generic.Dictionary<string, object?>>();
            foreach (DataRow r in dtDetails.Rows)
            {
                var dict = new System.Collections.Generic.Dictionary<string, object?>();
                foreach (DataColumn col in dtDetails.Columns)
                    dict[col.ColumnName] = r[col] == DBNull.Value ? null : r[col];
                detailRows.Add(dict);
            }

            string json = JsonConvert.SerializeObject(new { success = true, header = headerRows, details = detailRows });
            return Content(json, "application/json");
        }
    }
}
```

### 5.3.10 `Views/Shared/_Layout.cshtml`
**File Path:** `ShopManagement.Web/Views/Shared/_Layout.cshtml`

```html
@using Microsoft.AspNetCore.Http
@inject IHttpContextAccessor HttpContextAccessor
@{
    var role = HttpContextAccessor.HttpContext?.Session.GetString("Role") ?? "";
    var fullName = HttpContextAccessor.HttpContext?.Session.GetString("FullName") ?? "User";
    var username = HttpContextAccessor.HttpContext?.Session.GetString("Username") ?? "";
    bool isLoggedIn = !string.IsNullOrEmpty(role);
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>@ViewData["Title"] - Shop Management</title>

    <!-- Bootstrap 5 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" />

    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

    <!-- Kendo UI Styles -->
    <link rel="stylesheet" href="https://kendo.cdn.telerik.com/themes/7.0.2/default/default-main.css" />

    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" />

    <style>
        .app-wrapper { display: flex; min-height: 100vh; }
        .sidebar { width: 220px; flex-shrink: 0; }
        .sidebar-link { display: flex; align-items: center; gap: 8px; padding: 7px 12px; color: #adb5bd; text-decoration: none; border-radius: 4px; font-size: 13px; }
        .sidebar-link:hover { color: #fff; background: #343a40; }
        .sidebar-link.active { color: #fff; background: #0d6efd; }
        .sidebar-link i { width: 16px; text-align: center; }
        .main-content { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .page-body { padding: 1rem; flex: 1; }
        .card-custom { background: #fff; border: 1px solid #dee2e6; border-radius: 4px; margin-bottom: 1rem; }
    </style>

    <!-- jQuery & Kendo -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://kendo.cdn.telerik.com/2023.3.1114/js/kendo.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    @if (isLoggedIn)
    {
        <div class="app-wrapper">
            <!-- Sidebar -->
            <aside class="sidebar bg-dark d-flex flex-column">
                @{
                    var currentPath = (HttpContextAccessor.HttpContext?.Request.Path.Value ?? "").ToLowerInvariant();
                }
                <a href="@(role == "Admin" ? "/Product/Index" : "/Invoice/Create")" class="d-flex align-items-center gap-2 p-3 text-white text-decoration-none border-bottom border-secondary">
                    <i class="fa-solid fa-store"></i>
                    <span class="fw-bold">Shop Management</span>
                </a>
                <ul class="list-unstyled px-2 py-2 flex-grow-1">
                    @if (role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                    {
                        <li>
                            <a href="/Product/Index" class="sidebar-link @(currentPath == "/product" || currentPath.StartsWith("/product/index") ? "active" : "")">
                                <i class="fa-solid fa-boxes-stacked"></i>
                                <span>Product Inventory</span>
                            </a>
                        </li>
                        <li>
                            <a href="/Product/Import" class="sidebar-link @(currentPath.Contains("/product/import") ? "active" : "")">
                                <i class="fa-solid fa-file-excel"></i>
                                <span>Excel Bulk Import</span>
                            </a>
                        </li>
                        <li>
                            <a href="/Employee/Index" class="sidebar-link @(currentPath.Contains("/employee") ? "active" : "")">
                                <i class="fa-solid fa-users-gear"></i>
                                <span>Desk Logins</span>
                            </a>
                        </li>
                    }
                    else
                    {
                        <li>
                            <a href="/Invoice/Create" class="sidebar-link @(currentPath.Contains("/invoice/create") ? "active" : "")">
                                <i class="fa-solid fa-receipt"></i>
                                <span>New Invoice (POS)</span>
                            </a>
                        </li>
                        <li>
                            <a href="/Invoice/History" class="sidebar-link @(currentPath.Contains("/invoice/history") ? "active" : "")">
                                <i class="fa-solid fa-clock-rotate-left"></i>
                                <span>Invoice History</span>
                            </a>
                        </li>
                    }
                </ul>

                <div class="d-flex align-items-center justify-content-between p-3 border-top border-secondary">
                    <div>
                        <div class="fw-semibold text-white small">@fullName</div>
                        <span class="badge bg-secondary" style="font-size:11px;">@role</span>
                    </div>
                    <a href="/Account/Logout" class="text-danger" title="Logout">
                        <i class="fa-solid fa-right-from-bracket"></i>
                    </a>
                </div>
            </aside>

            <!-- Main Content -->
            <div class="main-content">
                <nav class="d-flex align-items-center justify-content-between px-3 border-bottom bg-white" style="height:50px;">
                    <div>
                        <h6 class="m-0 fw-bold text-dark">@ViewData["Title"]</h6>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <span class="text-muted small">User: <strong>@username</strong> (@role)</span>
                        <a href="/Account/Logout" class="btn btn-outline-danger btn-sm py-1 px-2">
                            <i class="fa-solid fa-arrow-right-from-bracket me-1"></i> Logout
                        </a>
                    </div>
                </nav>

                <main role="main" class="page-body">
                    @RenderBody()
                </main>
            </div>
        </div>
    }
    else
    {
        <main role="main">
            @RenderBody()
        </main>
    }

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @await RenderSectionAsync("Scripts", required: false)
</body>
</html>
```

### 5.3.11 `Views/Account/Login.cshtml`
**File Path:** `ShopManagement.Web/Views/Account/Login.cshtml`

```html
@{
    Layout = null;
    ViewData["Title"] = "Login";
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Shop Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
</head>
<body class="bg-light d-flex align-items-center justify-content-center" style="min-height: 100vh;">
    <div class="card shadow-sm border p-4" style="width: 380px; background: #fff;">
        <div class="text-center mb-4">
            <div class="mb-2">
                <i class="fa-solid fa-store fa-2x text-primary"></i>
            </div>
            <h4 class="fw-bold mb-1">Shop Management</h4>
            <p class="text-muted small">Enter your credentials to continue</p>
        </div>

        @if (ViewBag.Error != null)
        {
            <div class="alert alert-danger py-2 small mb-3">
                <i class="fa-solid fa-circle-exclamation me-1"></i> @ViewBag.Error
            </div>
        }

        <form method="post" action="/Account/Login">
            <div class="mb-3">
                <label class="form-label small fw-semibold">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-white"><i class="fa-regular fa-user text-muted"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="admin or desk1" required autofocus />
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-white"><i class="fa-solid fa-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required />
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">Sign In</button>
        </form>

        <div class="mt-4 pt-3 border-top small text-muted">
            <div class="fw-semibold mb-1">Default Logins:</div>
            <div>Admin: <code>admin</code> / <code>admin123</code></div>
            <div>Desk Cashier: <code>desk1</code> / <code>desk123</code></div>
        </div>
    </div>
</body>
</html>
```

### 5.3.12 `Views/Product/Index.cshtml`
**File Path:** `ShopManagement.Web/Views/Product/Index.cshtml`

```html
@{
    ViewData["Title"] = "Product Inventory";
    Layout = "_Layout";
}

<div class="mb-3 d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Product Inventory</h5>
    <div class="d-flex gap-2">
        <a href="/Product/Import" class="btn btn-sm btn-outline-secondary">
            <i class="fa-solid fa-file-excel me-1"></i> Bulk Import
        </a>
        <button type="button" class="btn btn-sm btn-primary" onclick="openUpsertModal()">
            <i class="fa-solid fa-plus me-1"></i> Add / Upsert Product
        </button>
    </div>
</div>

<div id="productsGrid"></div>

<!-- Add / Upsert Modal -->
<div class="modal fade" id="upsertProductModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h6 class="modal-title" id="upsertModalTitle"><i class="fa-solid fa-box me-1"></i> Add / Upsert Product</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="upsertProductForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Product Code *</label>
                        <input type="text" id="upsert_productCode" name="productCode" class="form-control form-control-sm" required />
                        <div class="text-muted" style="font-size:11px;">If code exists, stock will be added automatically.</div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Product Name *</label>
                        <input type="text" id="upsert_productName" name="productName" class="form-control form-control-sm" required />
                    </div>
                    <div class="row g-2 mb-2">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Quantity *</label>
                            <input type="number" id="upsert_quantity" name="quantity" class="form-control form-control-sm" min="0" value="1" required />
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Price (₹) *</label>
                            <input type="number" step="0.01" id="upsert_price" name="price" class="form-control form-control-sm" min="0" value="0.00" required />
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Product Image (Optional)</label>
                        <input type="file" id="upsert_imageFile" name="imageFile" class="form-control form-control-sm" accept="image/*" onchange="previewImage(this, 'upsert_imgPreview')" />
                        <div class="mt-2 text-center">
                            <img id="upsert_imgPreview" src="/images/products/default-product.svg" style="width:80px;height:80px;object-fit:cover;border:1px solid #dee2e6;border-radius:4px;" />
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm">Save Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editProductModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h6 class="modal-title"><i class="fa-solid fa-pen-to-square me-1"></i> Edit Product</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="editProductForm" enctype="multipart/form-data">
                <input type="hidden" id="edit_productId" name="productId" />
                <div class="modal-body">
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Product Code (Read-Only)</label>
                        <input type="text" id="edit_productCode" class="form-control form-control-sm bg-light" readonly />
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Product Name *</label>
                        <input type="text" id="edit_productName" name="productName" class="form-control form-control-sm" required />
                    </div>
                    <div class="row g-2 mb-2">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Exact Quantity *</label>
                            <input type="number" id="edit_quantity" name="quantity" class="form-control form-control-sm" min="0" required />
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Price (₹) *</label>
                            <input type="number" step="0.01" id="edit_price" name="price" class="form-control form-control-sm" min="0" required />
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Change Image (Optional)</label>
                        <input type="file" id="edit_imageFile" name="imageFile" class="form-control form-control-sm" accept="image/*" onchange="previewImage(this, 'edit_imgPreview')" />
                        <div class="mt-2 text-center">
                            <img id="edit_imgPreview" src="/images/products/default-product.svg" style="width:80px;height:80px;object-fit:cover;border:1px solid #dee2e6;border-radius:4px;" />
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm">Update Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

@section Scripts {
    <script src="/js/product.js"></script>
}
```

### 5.3.13 `wwwroot/js/product.js`
**File Path:** `ShopManagement.Web/wwwroot/js/product.js`

```javascript
$(document).ready(function () {
    loadProductsGrid();

    // Upsert Form Submit
    $("#upsertProductForm").on("submit", function (e) {
        e.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            url: "/Product/Add",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.success) {
                    Swal.fire({ icon: 'success', title: 'Success', text: res.message, timer: 1500, showConfirmButton: false });
                    $("#upsertProductModal").modal("hide");
                    $("#upsertProductForm")[0].reset();
                    $("#productsGrid").data("kendoGrid").dataSource.read();
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
            }
        });
    });

    // Edit Form Submit
    $("#editProductForm").on("submit", function (e) {
        e.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            url: "/Product/Edit",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.success) {
                    Swal.fire({ icon: 'success', title: 'Updated', text: res.message, timer: 1500, showConfirmButton: false });
                    $("#editProductModal").modal("hide");
                    $("#productsGrid").data("kendoGrid").dataSource.read();
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
            }
        });
    });
});

function loadProductsGrid() {
    $("#productsGrid").kendoGrid({
        dataSource: {
            transport: {
                read: { url: "/Product/GetProductsJson", dataType: "json" }
            },
            schema: {
                model: {
                    id: "ProductId",
                    fields: {
                        ProductId: { type: "number" },
                        ProductCode: { type: "string" },
                        ProductName: { type: "string" },
                        Quantity: { type: "number" },
                        Price: { type: "number" },
                        ImagePath: { type: "string" }
                    }
                }
            },
            pageSize: 10
        },
        pageable: { pageSizes: [5, 10, 20, 50], buttonCount: 5 },
        sortable: true,
        filterable: true,
        columns: [
            {
                field: "ImagePath",
                title: "Image",
                width: "70px",
                filterable: false,
                template: function (dataItem) {
                    var img = dataItem.ImagePath ? dataItem.ImagePath : "/images/products/default-product.svg";
                    return '<img src="' + img + '" style="width:38px;height:38px;object-fit:cover;border:1px solid #dee2e6;border-radius:4px;" />';
                }
            },
            { field: "ProductCode", title: "Code", width: "100px" },
            { field: "ProductName", title: "Product Name" },
            {
                field: "Quantity",
                title: "Stock",
                width: "90px",
                template: function (dataItem) {
                    var badgeClass = dataItem.Quantity <= 5 ? "bg-danger" : dataItem.Quantity <= 15 ? "bg-warning text-dark" : "bg-success";
                    return '<span class="badge ' + badgeClass + '">' + dataItem.Quantity + '</span>';
                }
            },
            {
                field: "Price",
                title: "Price",
                width: "110px",
                template: "₹ #: kendo.toString(Price, 'n2') #"
            },
            {
                title: "Actions",
                width: "140px",
                filterable: false,
                template: function (dataItem) {
                    return `
                        <button class="btn btn-outline-primary btn-sm py-0 px-2" onclick="openEditModal(${dataItem.ProductId})">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                        <button class="btn btn-outline-danger btn-sm py-0 px-2 ms-1" onclick="deleteProduct(${dataItem.ProductId}, '${dataItem.ProductName}')">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    `;
                }
            }
        ]
    });
}

function openUpsertModal() {
    $("#upsertProductForm")[0].reset();
    $("#upsert_imgPreview").attr("src", "/images/products/default-product.svg");
    $("#upsertProductModal").modal("show");
}

function openEditModal(productId) {
    $.getJSON("/Product/GetProductByIdJson?id=" + productId, function (data) {
        if (data && data.length > 0) {
            var item = data[0];
            $("#edit_productId").val(item.ProductId);
            $("#edit_productCode").val(item.ProductCode);
            $("#edit_productName").val(item.ProductName);
            $("#edit_quantity").val(item.Quantity);
            $("#edit_price").val(item.Price);
            var img = item.ImagePath ? item.ImagePath : "/images/products/default-product.svg";
            $("#edit_imgPreview").attr("src", img);
            $("#editProductModal").modal("show");
        }
    });
}

function deleteProduct(productId, name) {
    Swal.fire({
        title: 'Delete ' + name + '?',
        text: 'This product will be archived from inventory.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        confirmButtonText: 'Yes, Delete'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post("/Product/Delete", { productId: productId }, function (res) {
                if (res.success) {
                    Swal.fire('Deleted', res.message, 'success');
                    $("#productsGrid").data("kendoGrid").dataSource.read();
                } else {
                    Swal.fire('Error', res.message, 'error');
                }
            });
        }
    });
}

function previewImage(input, previewId) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $("#" + previewId).attr("src", e.target.result);
        };
        reader.readAsDataURL(input.files[0]);
    }
}
```

### 5.3.14 `Views/Product/Import.cshtml`
**File Path:** `ShopManagement.Web/Views/Product/Import.cshtml`

```html
@model System.Data.DataTable
@{
    ViewData["Title"] = "Excel Bulk Import";
    Layout = "_Layout";
}

<div class="mb-3 d-flex justify-content-between align-items-center">
    <div>
        <h5 class="mb-0">Excel Bulk Product Import</h5>
        <div class="text-muted small">Upload an Excel spreadsheet (.xlsx) to bulk insert or update products.</div>
    </div>
    <a href="/Product/DownloadTemplate" class="btn btn-sm btn-outline-success">
        <i class="fa-solid fa-file-arrow-down me-1"></i> Download Template (.xlsx)
    </a>
</div>

<div class="card mb-4 border">
    <div class="card-body">
        <form method="post" enctype="multipart/form-data" action="/Product/Import">
            <div class="row align-items-end g-2">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Choose Excel File (.xlsx)</label>
                    <input type="file" name="excelFile" class="form-control form-control-sm" accept=".xlsx" required />
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary btn-sm w-100">
                        <i class="fa-solid fa-upload me-1"></i> Upload & Process
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

@if (ViewBag.Success == true)
{
    <div class="row g-2 mb-3">
        <div class="col-3">
            <div class="border rounded p-2 text-center bg-white">
                <div class="text-muted small">Total Processed</div>
                <div class="fw-bold fs-5">@ViewBag.Total</div>
            </div>
        </div>
        <div class="col-3">
            <div class="border rounded p-2 text-center bg-white text-success">
                <div class="small">Inserted New</div>
                <div class="fw-bold fs-5">@ViewBag.Inserted</div>
            </div>
        </div>
        <div class="col-3">
            <div class="border rounded p-2 text-center bg-white text-primary">
                <div class="small">Stock Updated</div>
                <div class="fw-bold fs-5">@ViewBag.Updated</div>
            </div>
        </div>
        <div class="col-3">
            <div class="border rounded p-2 text-center bg-white text-danger">
                <div class="small">Failed</div>
                <div class="fw-bold fs-5">@ViewBag.Failed</div>
            </div>
        </div>
    </div>

    @if (Model != null && Model.Rows.Count > 0)
    {
        <div class="table-responsive">
            <table class="table table-bordered table-sm bg-white">
                <thead class="table-light">
                    <tr>
                        <th>Row</th>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach (System.Data.DataRow r in Model.Rows)
                    {
                        var status = r["Status"].ToString();
                        <tr class="@(status == "Success" ? "" : "table-danger")">
                            <td>@r["RowNumber"]</td>
                            <td>@r["ProductCode"]</td>
                            <td>@r["ProductName"]</td>
                            <td>@r["Quantity"]</td>
                            <td>₹@Convert.ToDecimal(r["Price"]).ToString("N2")</td>
                            <td>
                                <span class="badge @(status == "Success" ? "bg-success" : "bg-danger")">@status</span>
                            </td>
                            <td class="small">@r["Message"]</td>
                        </tr>
                    }
                </tbody>
            </table>
        </div>
    }
}
```

### 5.3.15 `Views/Invoice/Create.cshtml`
**File Path:** `ShopManagement.Web/Views/Invoice/Create.cshtml`  
**Role:** Real-time billing POS screen. Uses live product search, auto-increments quantity in line items table, computes totals, submits JSON payload via AJAX.

```html
@{
    ViewData["Title"] = "New Invoice (POS)";
    Layout = "_Layout";
}

<div class="row g-3">
    <!-- Left Column: Customer details & product selector -->
    <div class="col-md-4">
        <div class="card border">
            <div class="card-header bg-dark text-white py-2">
                <h6 class="mb-0"><i class="fa-solid fa-user me-1"></i> Customer & Product Search</h6>
            </div>
            <div class="card-body">
                <div class="mb-2">
                    <label class="form-label small fw-semibold">Customer Name *</label>
                    <input type="text" id="custName" class="form-control form-control-sm" placeholder="e.g. Ramesh Sharma" required />
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Phone Number</label>
                    <input type="text" id="custPhone" class="form-control form-control-sm" placeholder="e.g. 9876543210" />
                </div>

                <hr class="my-2" />

                <label class="form-label small fw-semibold">Search Product (Code or Name)</label>
                <div class="input-group input-group-sm mb-2">
                    <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" id="productSearchInput" class="form-control" placeholder="Type name or code..." onkeyup="searchProducts()" />
                </div>

                <!-- Live Search Results Dropdown -->
                <div id="searchResultsList" class="border rounded bg-white" style="max-height: 250px; overflow-y: auto; display: none;"></div>
            </div>
        </div>
    </div>

    <!-- Right Column: Cart items table & Billing summary -->
    <div class="col-md-8">
        <div class="card border">
            <div class="card-header bg-dark text-white py-2 d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fa-solid fa-cart-shopping me-1"></i> Bill Items</h6>
                <button type="button" class="btn btn-outline-light btn-sm py-0" onclick="clearCart()">Clear</button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive" style="min-height: 280px;">
                    <table class="table table-sm table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 40px;">#</th>
                                <th>Product Details</th>
                                <th style="width: 110px;">Unit Price</th>
                                <th style="width: 120px;" class="text-center">Quantity</th>
                                <th style="width: 120px;" class="text-end">Total</th>
                                <th style="width: 50px;"></th>
                            </tr>
                        </thead>
                        <tbody id="cartTableBody">
                            <tr id="emptyCartRow">
                                <td colspan="6" class="text-center text-muted py-4">
                                    <i class="fa-solid fa-basket-shopping fa-2x mb-2 d-block text-secondary"></i>
                                    No products added. Search and click a product on the left to add it.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="p-3 border-top bg-light d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small">Total Items: <strong id="totalItemsCount">0</strong></div>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <div class="text-end">
                            <span class="text-muted small">Grand Total:</span>
                            <div class="fs-4 fw-bold text-primary" id="grandTotalText">₹0.00</div>
                        </div>
                        <button type="button" class="btn btn-success px-4 py-2" onclick="submitInvoice()">
                            <i class="fa-solid fa-circle-check me-1"></i> Generate Invoice
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@section Scripts {
<script>
    var cart = [];

    function searchProducts() {
        var term = $("#productSearchInput").val().trim();
        if (term.length < 1) {
            $("#searchResultsList").hide().empty();
            return;
        }

        $.getJSON("/Product/SearchAvailable?term=" + encodeURIComponent(term), function(data) {
            var $list = $("#searchResultsList");
            $list.empty();

            if (!data || data.length === 0) {
                $list.html('<div class="p-2 text-muted small text-center">No products found</div>').show();
                return;
            }

            $.each(data, function(idx, p) {
                var img = p.ImagePath ? p.ImagePath : "/images/products/default-product.svg";
                var rowHtml = `
                    <div class="d-flex align-items-center justify-content-between p-2 border-bottom cursor-pointer hover-bg"
                         onclick="addToCart(${p.ProductId}, '${escapeHtml(p.ProductName)}', ${p.Price}, ${p.Quantity})">
                        <div class="d-flex align-items-center gap-2">
                            <img src="${img}" style="width:32px;height:32px;object-fit:cover;border-radius:4px;border:1px solid #dee2e6;" />
                            <div>
                                <div class="fw-semibold small">${escapeHtml(p.ProductName)}</div>
                                <div class="text-muted" style="font-size:11px;">${p.ProductCode} | Stock: ${p.Quantity}</div>
                            </div>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold small text-primary">₹${parseFloat(p.Price).toFixed(2)}</div>
                            <span class="badge bg-secondary" style="font-size:10px;">+ Add</span>
                        </div>
                    </div>
                `;
                $list.append(rowHtml);
            });
            $list.show();
        });
    }

    function addToCart(productId, productName, unitPrice, availableStock) {
        var existing = cart.find(x => x.productId === productId);
        if (existing) {
            if (existing.quantity + 1 > availableStock) {
                Swal.fire({ icon: 'warning', title: 'Stock Limit', text: 'Cannot add more. Max stock available: ' + availableStock });
                return;
            }
            existing.quantity += 1;
        } else {
            cart.push({
                productId: productId,
                productName: productName,
                unitPrice: parseFloat(unitPrice),
                quantity: 1,
                availableStock: availableStock
            });
        }
        $("#searchResultsList").hide().empty();
        $("#productSearchInput").val("");
        renderCart();
    }

    function renderCart() {
        var $tbody = $("#cartTableBody");
        $tbody.empty();

        if (cart.length === 0) {
            $tbody.html(`
                <tr id="emptyCartRow">
                    <td colspan="6" class="text-center text-muted py-4">
                        <i class="fa-solid fa-basket-shopping fa-2x mb-2 d-block text-secondary"></i>
                        No products added. Search and click a product on the left to add it.
                    </td>
                </tr>
            `);
            $("#totalItemsCount").text("0");
            $("#grandTotalText").text("₹0.00");
            return;
        }

        var grandTotal = 0;
        var totalQty = 0;

        $.each(cart, function(idx, item) {
            var lineTotal = item.quantity * item.unitPrice;
            grandTotal += lineTotal;
            totalQty += item.quantity;

            var tr = `
                <tr>
                    <td>${idx + 1}</td>
                    <td>
                        <div class="fw-semibold small">${escapeHtml(item.productName)}</div>
                        <div class="text-muted" style="font-size:11px;">Max Stock: ${item.availableStock}</div>
                    </td>
                    <td>₹${item.unitPrice.toFixed(2)}</td>
                    <td class="text-center">
                        <div class="input-group input-group-sm justify-content-center" style="width: 100px; margin: 0 auto;">
                            <button class="btn btn-outline-secondary" type="button" onclick="updateQty(${idx}, -1)">-</button>
                            <input type="text" class="form-control text-center p-0" value="${item.quantity}" readonly />
                            <button class="btn btn-outline-secondary" type="button" onclick="updateQty(${idx}, 1)">+</button>
                        </div>
                    </td>
                    <td class="text-end fw-semibold">₹${lineTotal.toFixed(2)}</td>
                    <td class="text-center">
                        <button class="btn btn-link text-danger p-0" onclick="removeFromCart(${idx})">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </td>
                </tr>
            `;
            $tbody.append(tr);
        });

        $("#totalItemsCount").text(totalQty);
        $("#grandTotalText").text("₹" + grandTotal.toFixed(2));
    }

    function updateQty(index, delta) {
        var item = cart[index];
        var newQty = item.quantity + delta;

        if (newQty <= 0) {
            cart.splice(index, 1);
        } else if (newQty > item.availableStock) {
            Swal.fire({ icon: 'warning', title: 'Stock Limit', text: 'Max stock available is ' + item.availableStock });
            return;
        } else {
            item.quantity = newQty;
        }
        renderCart();
    }

    function removeFromCart(index) {
        cart.splice(index, 1);
        renderCart();
    }

    function clearCart() {
        cart = [];
        renderCart();
    }

    function submitInvoice() {
        var custName = $("#custName").val().trim();
        var custPhone = $("#custPhone").val().trim();

        if (!custName) {
            Swal.fire({ icon: 'warning', title: 'Validation', text: 'Please enter customer name.' });
            return;
        }

        if (cart.length === 0) {
            Swal.fire({ icon: 'warning', title: 'Validation', text: 'Cart is empty. Add at least one product.' });
            return;
        }

        var postData = {
            customerName: custName,
            customerPhone: custPhone,
            itemsJson: JSON.stringify(cart)
        };

        $.post("/Invoice/Create", postData, function(res) {
            if (res.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Invoice Created!',
                    text: 'Invoice No: ' + res.invoiceNo,
                    confirmButtonText: 'View History'
                }).then(() => {
                    window.location.href = "/Invoice/History";
                });
            } else {
                Swal.fire({ icon: 'error', title: 'Billing Failed', text: res.message });
            }
        });
    }

    function escapeHtml(text) {
        return text ? text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;") : '';
    }
</script>
}
```

### 5.3.16 `Views/Invoice/History.cshtml`
**File Path:** `ShopManagement.Web/Views/Invoice/History.cshtml`  
**Role:** Invoices Kendo Grid with View Details popup modal and printable thermal/A4 Bill formatting.

```html
@{
    ViewData["Title"] = "Invoice History";
    Layout = "_Layout";
}

<div class="mb-3 d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Invoice History</h5>
    <a href="/Invoice/Create" class="btn btn-sm btn-primary">
        <i class="fa-solid fa-plus me-1"></i> New Invoice (POS)
    </a>
</div>

<div id="invoicesGrid"></div>

<!-- Invoice Details Modal -->
<div class="modal fade" id="invoiceDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h6 class="modal-title"><i class="fa-solid fa-receipt me-1"></i> Invoice Details - <span id="modalInvoiceNo"></span></h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4" id="printableInvoiceArea">
                <div class="d-flex justify-content-between border-bottom pb-3 mb-3">
                    <div>
                        <h5 class="fw-bold mb-0">Shop Management</h5>
                        <div class="text-muted small">Tax Invoice / Cash Receipt</div>
                    </div>
                    <div class="text-end small">
                        <div><strong>Invoice #:</strong> <span id="infoInvNo"></span></div>
                        <div><strong>Date:</strong> <span id="infoInvDate"></span></div>
                        <div><strong>Billed By:</strong> <span id="infoBilledBy"></span></div>
                    </div>
                </div>

                <div class="mb-3 small">
                    <strong>Customer:</strong> <span id="infoCustName"></span> | 
                    <strong>Phone:</strong> <span id="infoCustPhone"></span>
                </div>

                <table class="table table-bordered table-sm align-middle">
                    <thead class="table-light small">
                        <tr>
                            <th>#</th>
                            <th>Product Details</th>
                            <th class="text-center">Qty</th>
                            <th class="text-end">Unit Price</th>
                            <th class="text-end">Total Amount</th>
                        </tr>
                    </thead>
                    <tbody id="modalInvoiceDetailsBody"></tbody>
                    <tfoot>
                        <tr>
                            <th colspan="4" class="text-end">Grand Total:</th>
                            <th class="text-end text-primary fs-6" id="modalGrandTotal">₹0.00</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-dark btn-sm" onclick="printInvoiceModal()">
                    <i class="fa-solid fa-print me-1"></i> Print Bill
                </button>
            </div>
        </div>
    </div>
</div>

@section Scripts {
<script>
    $(document).ready(function () {
        loadInvoicesGrid();
    });

    function loadInvoicesGrid() {
        $("#invoicesGrid").kendoGrid({
            dataSource: {
                transport: { read: { url: "/Invoice/GetInvoicesJson", dataType: "json" } },
                schema: {
                    model: {
                        id: "InvoiceId",
                        fields: {
                            InvoiceId: { type: "number" },
                            InvoiceNo: { type: "string" },
                            CustomerName: { type: "string" },
                            CustomerPhone: { type: "string" },
                            TotalAmount: { type: "number" },
                            InvoiceDate: { type: "date" },
                            CreatedByName: { type: "string" }
                        }
                    }
                },
                pageSize: 10
            },
            pageable: { pageSizes: [10, 25, 50] },
            sortable: true,
            filterable: true,
            columns: [
                { field: "InvoiceNo", title: "Invoice No", width: "160px" },
                { field: "CustomerName", title: "Customer Name" },
                { field: "CustomerPhone", title: "Phone", width: "130px" },
                { field: "CreatedByName", title: "Cashier", width: "140px" },
                { field: "InvoiceDate", title: "Date & Time", width: "170px", template: "#= kendo.toString(kendo.parseDate(InvoiceDate), 'dd-MMM-yyyy hh:mm tt') #" },
                { field: "TotalAmount", title: "Total Amount", width: "130px", template: "₹ #: kendo.toString(TotalAmount, 'n2') #" },
                {
                    title: "Actions", width: "130px", filterable: false,
                    template: function (dataItem) {
                        return `<button class="btn btn-outline-primary btn-sm py-0 px-2" onclick="viewInvoiceDetails(${dataItem.InvoiceId})"><i class="fa-solid fa-eye me-1"></i> Details</button>`;
                    }
                }
            ]
        });
    }

    function viewInvoiceDetails(invoiceId) {
        $.getJSON("/Invoice/GetInvoiceDetailsJson?id=" + invoiceId, function (res) {
            if (res.success && res.header.length > 0) {
                var h = res.header[0];
                $("#modalInvoiceNo, #infoInvNo").text(h.InvoiceNo);
                $("#infoInvDate").text(kendo.toString(kendo.parseDate(h.InvoiceDate), 'dd-MMM-yyyy hh:mm tt'));
                $("#infoCustName").text(h.CustomerName);
                $("#infoCustPhone").text(h.CustomerPhone || "N/A");
                $("#infoBilledBy").text(h.CreatedByName);
                $("#modalGrandTotal").text("₹" + parseFloat(h.TotalAmount).toFixed(2));

                var $tbody = $("#modalInvoiceDetailsBody");
                $tbody.empty();

                $.each(res.details, function (idx, d) {
                    $tbody.append(`
                        <tr>
                            <td>${idx + 1}</td>
                            <td><strong>${d.ProductName}</strong> <span class="text-muted small">(${d.ProductCode || ''})</span></td>
                            <td class="text-center">${d.Quantity}</td>
                            <td class="text-end">₹${parseFloat(d.UnitPrice).toFixed(2)}</td>
                            <td class="text-end">₹${parseFloat(d.TotalAmount).toFixed(2)}</td>
                        </tr>
                    `);
                });

                $("#invoiceDetailsModal").modal("show");
            }
        });
    }

    function printInvoiceModal() {
        var printContents = document.getElementById("printableInvoiceArea").innerHTML;
        var printWindow = window.open('', '', 'height=650,width=800');
        printWindow.document.write('<html><head><title>Print Invoice</title>');
        printWindow.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">');
        printWindow.document.write('</head><body class="p-4">');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        setTimeout(function () {
            printWindow.print();
            printWindow.close();
        }, 500);
    }
</script>
}
```

### 5.3.17 `Views/Employee/Index.cshtml`
**File Path:** `ShopManagement.Web/Views/Employee/Index.cshtml`

```html
@{
    ViewData["Title"] = "Desk Logins";
    Layout = "_Layout";
}

<div class="mb-3 d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Desk Logins Management</h5>
    <button type="button" class="btn btn-sm btn-primary" onclick="openAddEmployeeModal()">
        <i class="fa-solid fa-user-plus me-1"></i> Add Desk Login
    </button>
</div>

<div id="employeesGrid"></div>

<!-- Add Modal -->
<div class="modal fade" id="addEmployeeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h6 class="modal-title"><i class="fa-solid fa-user-plus me-1"></i> New Desk Login</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="addEmployeeForm">
                <div class="modal-body">
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Staff Full Name *</label>
                        <input type="text" name="name" class="form-control form-control-sm" required />
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Username *</label>
                        <input type="text" name="username" class="form-control form-control-sm" required />
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Password *</label>
                        <input type="password" name="password" class="form-control form-control-sm" required />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm">Create Login</button>
                </div>
            </form>
        </div>
    </div>
</div>

@section Scripts {
<script>
    $(document).ready(function() {
        loadEmployeesGrid();

        $("#addEmployeeForm").on("submit", function(e) {
            e.preventDefault();
            $.post("/Employee/Add", $(this).serialize(), function(res) {
                if (res.success) {
                    Swal.fire({ icon: 'success', title: 'Created', text: res.message, timer: 1500, showConfirmButton: false });
                    $("#addEmployeeModal").modal("hide");
                    $("#addEmployeeForm")[0].reset();
                    $("#employeesGrid").data("kendoGrid").dataSource.read();
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
            });
        });
    });

    function loadEmployeesGrid() {
        $("#employeesGrid").kendoGrid({
            dataSource: {
                transport: { read: { url: "/Employee/GetEmployeesJson", dataType: "json" } },
                schema: {
                    model: {
                        id: "UserId",
                        fields: {
                            UserId: { type: "number" },
                            Name: { type: "string" },
                            Username: { type: "string" },
                            Role: { type: "string" },
                            StoreName: { type: "string" },
                            IsActive: { type: "number" }
                        }
                    }
                },
                pageSize: 10
            },
            pageable: true,
            sortable: true,
            columns: [
                { field: "Name", title: "Full Name" },
                { field: "Username", title: "Username" },
                { field: "Role", title: "Role", width: "110px" },
                { field: "StoreName", title: "Branch / Store", width: "160px" },
                {
                    field: "IsActive", title: "Status", width: "100px",
                    template: function(d) {
                        return d.IsActive === 1 ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Disabled</span>';
                    }
                },
                {
                    title: "Actions", width: "120px", filterable: false,
                    template: function(d) {
                        return `<button class="btn btn-outline-secondary btn-sm py-0 px-2" onclick="toggleStatus(${d.UserId})">Toggle Active</button>`;
                    }
                }
            ]
        });
    }

    function openAddEmployeeModal() {
        $("#addEmployeeForm")[0].reset();
        $("#addEmployeeModal").modal("show");
    }

    function toggleStatus(userId) {
        $.post("/Employee/ToggleStatus", { userId: userId }, function(res) {
            $("#employeesGrid").data("kendoGrid").dataSource.read();
        });
    }
</script>
}
```

### 5.3.18 `Views/Store/Index.cshtml`
**File Path:** `ShopManagement.Web/Views/Store/Index.cshtml`

```html
@{
    ViewData["Title"] = "Stores & Branches";
    Layout = "_Layout";
}

<div class="mb-3 d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Stores & Branch Management</h5>
    <button type="button" class="btn btn-sm btn-primary" onclick="openAddStoreModal()">
        <i class="fa-solid fa-store me-1"></i> Add Branch
    </button>
</div>

<div id="storesGrid"></div>

<!-- Add Store Modal -->
<div class="modal fade" id="addStoreModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h6 class="modal-title"><i class="fa-solid fa-store me-1"></i> Add New Branch</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="addStoreForm">
                <div class="modal-body">
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Store Code *</label>
                        <input type="text" name="storeCode" class="form-control form-control-sm" placeholder="e.g. BR02" required />
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Store Name *</label>
                        <input type="text" name="storeName" class="form-control form-control-sm" placeholder="e.g. West Branch" required />
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Phone</label>
                        <input type="text" name="phone" class="form-control form-control-sm" />
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Address</label>
                        <input type="text" name="address" class="form-control form-control-sm" />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm">Save Store</button>
                </div>
            </form>
        </div>
    </div>
</div>

@section Scripts {
<script>
    $(document).ready(function() {
        loadStoresGrid();

        $("#addStoreForm").on("submit", function(e) {
            e.preventDefault();
            $.post("/Store/Create", $(this).serialize(), function(res) {
                if (res.success) {
                    Swal.fire({ icon: 'success', title: 'Saved', text: res.message, timer: 1500, showConfirmButton: false });
                    $("#addStoreModal").modal("hide");
                    $("#addStoreForm")[0].reset();
                    $("#storesGrid").data("kendoGrid").dataSource.read();
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: res.message });
                }
            });
        });
    });

    function loadStoresGrid() {
        $("#storesGrid").kendoGrid({
            dataSource: {
                transport: { read: { url: "/Store/GetStoresJson", dataType: "json" } },
                schema: {
                    model: {
                        id: "StoreId",
                        fields: {
                            StoreId: { type: "number" },
                            StoreCode: { type: "string" },
                            StoreName: { type: "string" },
                            Phone: { type: "string" },
                            Address: { type: "string" },
                            IsActive: { type: "number" }
                        }
                    }
                },
                pageSize: 10
            },
            pageable: true,
            sortable: true,
            columns: [
                { field: "StoreCode", title: "Code", width: "100px" },
                { field: "StoreName", title: "Store Name" },
                { field: "Phone", title: "Phone", width: "140px" },
                { field: "Address", title: "Address" },
                {
                    field: "IsActive", title: "Status", width: "100px",
                    template: function(d) {
                        return d.IsActive === 1 ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>';
                    }
                }
            ]
        });
    }

    function openAddStoreModal() {
        $("#addStoreForm")[0].reset();
        $("#addStoreModal").modal("show");
    }
</script>
}
```

---

# 6. End-to-End Data Flow Deep Dive

### How a Record Travels from MySQL to Kendo Grid:
```
1. MySQL Table: Products
   [ProductId: 1, ProductCode: "P001", ProductName: "Parker Pen", Quantity: 100, Price: 150.00]
         │
         ▼
2. DAL: ProductDAL.GetAllProducts()
   DbHelper.ExecuteDataTable(query)
   -> MySqlDataAdapter fills ADO.NET System.Data.DataTable with Schema & DataRows
         │
         ▼
3. BAL: ProductBAL.GetAllProducts()
   Passes the DataTable through business boundary (adds auditing / caching if needed)
         │
         ▼
4. Controller: ProductController.GetProductsJson()
   Newtonsoft.Json.JsonConvert.SerializeObject(dt) converts DataTable directly to JSON string:
   [{"ProductId":1,"ProductCode":"P001","ProductName":"Parker Pen","Quantity":100,"Price":150.00}]
   Returns Content(json, "application/json")
         │
         ▼
5. Browser / Kendo Grid:
   kendoGrid dataSource transport fetches URL "/Product/GetProductsJson"
   Kendo schema model maps fields and types
   Column template formats Currency (₹ 150.00) and badges
   Renders <tr> and <td> DOM elements in HTML table!
```

---

# 7. Step-by-Step Setup, Build & Run Guide

### Step 1: Database Setup
1. Ensure MySQL Server is running on port `3306`.
2. Open MySQL CLI or MySQL Workbench:
   ```bash
   mysql -u root -p
   ```
3. Run the SQL script:
   ```sql
   SOURCE d:/Download/mv-baldal/Database_Setup.sql;
   ```

### Step 2: Configure Connection String
Open `ShopManagement.Web/appsettings.json` and ensure your credentials match:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=ShopManagementDB;User ID=root;Password=YOUR_PASSWORD;Port=3306;AllowUserVariables=True;"
  }
}
```

### Step 3: Build the Solution
```bash
dotnet build ShopManagement.sln -c Release
```

### Step 4: Run the Application
```bash
dotnet run --project ShopManagement.Web/ShopManagement.Web.csproj -c Release --urls "http://localhost:5200"
```

### Step 5: Open in Browser
Navigate to:
👉 **`http://localhost:5200`**

### Step 6: Test Default Logins
| Role | Username | Password | Default Redirect Page |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin` | `admin123` | Product Inventory (`/Product/Index`) |
| **Employee / Cashier** | `desk1` | `desk123` | POS Billing Counter (`/Invoice/Create`) |

---
*Documentation compiled and verified for Shop Management 3-Tier Enterprise Architecture.*
