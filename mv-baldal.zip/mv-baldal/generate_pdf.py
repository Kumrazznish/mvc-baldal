import os
import re
import markdown
import subprocess

md_path = r"d:\Download\mv-baldal\PROJECT_DOCUMENTATION.md"
html_path = r"d:\Download\mv-baldal\PROJECT_DOCUMENTATION.html"
pdf_path = r"d:\Download\mv-baldal\ShopManagement_Project_Documentation.pdf"

with open(md_path, "r", encoding="utf-8") as f:
    md_content = f.read()

# Convert Markdown to HTML
html_body = markdown.markdown(
    md_content,
    extensions=["extra", "toc", "tables", "sane_lists"]
)

# Custom HTML template with print-ready CSS
full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop Management System - Project Documentation</title>
    <!-- Highlight.js Stylesheet -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css">
    <style>
        @page {{
            size: A4;
            margin: 15mm 15mm 15mm 15mm;
            @bottom-right {{
                content: counter(page);
                font-size: 9pt;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                color: #64748b;
            }}
        }}

        @media print {{
            body {{
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }}
            .page-break {{
                page-break-before: always;
            }}
            pre, blockquote, table, .card {{
                page-break-inside: avoid;
            }}
            h1, h2, h3, h4 {{
                page-break-after: avoid;
            }}
        }}

        * {{
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            font-size: 10.5pt;
            line-height: 1.55;
            color: #1e293b;
            background: #ffffff;
            margin: 0;
            padding: 20px 30px;
        }}

        /* Cover Banner */
        .cover-header {{
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
            color: #ffffff;
            padding: 35px 30px;
            border-radius: 12px;
            margin-bottom: 25px;
            border: 1px solid #0f172a;
        }}
        .cover-header h1 {{
            margin: 0 0 10px 0;
            font-size: 24pt;
            font-weight: 800;
            color: #ffffff;
            border-bottom: none;
            padding-bottom: 0;
        }}
        .cover-header .subtitle {{
            font-size: 12pt;
            color: #94a3b8;
            margin-bottom: 18px;
        }}
        .badge-list {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }}
        .badge {{
            display: inline-block;
            background: rgba(255, 255, 255, 0.15);
            color: #e2e8f0;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 8.5pt;
            font-weight: 600;
            letter-spacing: 0.5px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }}

        h1 {{
            font-size: 18pt;
            font-weight: 700;
            color: #0f172a;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 8px;
            margin-top: 35px;
            margin-bottom: 16px;
        }}

        h2 {{
            font-size: 14pt;
            font-weight: 700;
            color: #1e293b;
            border-bottom: 1px solid #f1f5f9;
            padding-bottom: 6px;
            margin-top: 26px;
            margin-bottom: 14px;
        }}

        h3 {{
            font-size: 12pt;
            font-weight: 600;
            color: #2563eb;
            margin-top: 20px;
            margin-bottom: 10px;
        }}

        h4 {{
            font-size: 11pt;
            font-weight: 600;
            color: #334155;
            margin-top: 16px;
            margin-bottom: 8px;
        }}

        p {{
            margin: 8px 0 12px 0;
        }}

        a {{
            color: #2563eb;
            text-decoration: none;
            font-weight: 500;
        }}

        blockquote {{
            background: #f8fafc;
            border-left: 4px solid #2563eb;
            margin: 15px 0;
            padding: 10px 18px;
            color: #334155;
            border-radius: 0 8px 8px 0;
            font-size: 10pt;
        }}

        /* Code Blocks */
        pre {{
            background: #0d1117 !important;
            border-radius: 8px;
            padding: 14px 16px;
            overflow-x: auto;
            border: 1px solid #30363d;
            margin: 14px 0;
            page-break-inside: avoid;
        }}

        code {{
            font-family: "Cascadia Code", "Fira Code", Consolas, "Courier New", monospace;
            font-size: 9pt;
            line-height: 1.45;
        }}

        pre code {{
            color: #e6edf3;
            background: transparent !important;
            padding: 0;
        }}

        p code, li code, td code {{
            background: #f1f5f9;
            color: #0f172a;
            padding: 2px 6px;
            border-radius: 4px;
            border: 1px solid #e2e8f0;
            font-size: 8.5pt;
        }}

        /* Tables */
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 16px 0;
            font-size: 9.5pt;
            background: #ffffff;
            page-break-inside: avoid;
        }}

        th, td {{
            padding: 8px 12px;
            border: 1px solid #e2e8f0;
            text-align: left;
        }}

        th {{
            background: #f8fafc;
            color: #0f172a;
            font-weight: 600;
        }}

        tr:nth-child(even) {{
            background: #fcfdfe;
        }}

        /* Lists */
        ul, ol {{
            margin: 8px 0 14px 0;
            padding-left: 24px;
        }}

        li {{
            margin-bottom: 4px;
        }}

        hr {{
            border: none;
            border-top: 1px solid #e2e8f0;
            margin: 25px 0;
        }}
    </style>
</head>
<body>

<div class="cover-header">
    <h1>🏪 Shop Management System</h1>
    <div class="subtitle">Complete 3-Tier Enterprise Architecture Guide & Source Code Reference Manual</div>
    <div class="badge-list">
        <span class="badge">ASP.NET Core MVC (v8/10)</span>
        <span class="badge">3-Tier (DAL / BAL / Web)</span>
        <span class="badge">MySQL Database</span>
        <span class="badge">ADO.NET / DbHelper</span>
        <span class="badge">Kendo UI Grid</span>
        <span class="badge">ClosedXML (Excel Import/Export)</span>
        <span class="badge">POS Live Billing & Stock Deduct</span>
    </div>
</div>

{html_body}

<!-- Highlight.js JS for Syntax Coloring -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/csharp.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/sql.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/json.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/xml.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', (event) => {{
        document.querySelectorAll('pre code').forEach((el) => {{
            hljs.highlightElement(el);
        }});
    }});
</script>
</body>
</html>
"""

with open(html_path, "w", encoding="utf-8") as f:
    f.write(full_html)

print(f"Generated HTML at: {html_path}")

# Run Chrome Headless to generate PDF
chrome_cmd = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "--headless=new",
    "--disable-gpu",
    "--no-sandbox",
    "--run-all-compositor-stages-before-draw",
    "--virtual-time-budget=4000",
    f"--print-to-pdf={pdf_path}",
    html_path
]

print("Executing Chrome headless print-to-pdf...")
res = subprocess.run(chrome_cmd, capture_output=True, text=True)
print("Chrome Return Code:", res.returncode)

if os.path.exists(pdf_path):
    size_mb = os.path.getsize(pdf_path) / (1024 * 1024)
    print(f"SUCCESS: PDF generated at: {pdf_path} (Size: {size_mb:.2f} MB)")
else:
    print("FAILED to create PDF. Trying Edge...")
    edge_cmd = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        "--virtual-time-budget=4000",
        f"--print-to-pdf={pdf_path}",
        html_path
    ]
    res_edge = subprocess.run(edge_cmd, capture_output=True, text=True)
    if os.path.exists(pdf_path):
        size_mb = os.path.getsize(pdf_path) / (1024 * 1024)
        print(f"SUCCESS (via Edge): PDF generated at: {pdf_path} (Size: {size_mb:.2f} MB)")
    else:
        print("Edge stderr:", res_edge.stderr)
