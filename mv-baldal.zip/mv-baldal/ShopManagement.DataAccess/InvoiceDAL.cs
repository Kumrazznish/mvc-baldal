using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class InvoiceDAL
    {
        public bool CreateInvoice(string customerName, string customerPhone, int createdBy, DataTable items, out string invoiceNo, out string errorMessage)
        {
            invoiceNo = "INV-" + DateTime.Now.ToString("yyyyMMddHHmmss");
            errorMessage = string.Empty;

            using (var conn = DbHelper.GetConnection())
            using (var trans = conn.BeginTransaction())
            {
                try
                {
                    decimal grandTotal = 0;

                    // 1. Validate items and stock availability first
                    foreach (DataRow row in items.Rows)
                    {
                        int productId = Convert.ToInt32(row["ProductId"]);
                        int qty = Convert.ToInt32(row["Quantity"]);
                        decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                        decimal lineTotal = qty * unitPrice;
                        grandTotal += lineTotal;

                        string checkStockQuery = "SELECT ProductName, Quantity FROM Products WHERE ProductId = @ProductId FOR UPDATE;";
                        using (var checkCmd = new MySqlCommand(checkStockQuery, conn, trans))
                        {
                            checkCmd.Parameters.AddWithValue("@ProductId", productId);
                            using (var reader = checkCmd.ExecuteReader())
                            {
                                if (!reader.Read())
                                {
                                    reader.Close();
                                    errorMessage = $"Product ID {productId} does not exist.";
                                    trans.Rollback();
                                    return false;
                                }

                                string prodName = reader.GetString("ProductName");
                                int currentStock = reader.GetInt32("Quantity");
                                reader.Close();

                                if (currentStock < qty)
                                {
                                    errorMessage = $"Insufficient stock for '{prodName}'. Available: {currentStock}, Requested: {qty}.";
                                    trans.Rollback();
                                    return false;
                                }
                            }
                        }
                    }

                    // 2. Insert Invoice Header
                    string insertInvoiceQuery = @"
                        INSERT INTO Invoices (InvoiceNo, CustomerName, CustomerPhone, CreatedBy, InvoiceDate, TotalAmount)
                        VALUES (@InvoiceNo, @CustomerName, @CustomerPhone, @CreatedBy, NOW(), @TotalAmount);
                        SELECT LAST_INSERT_ID();";

                    int invoiceId;
                    using (var invCmd = new MySqlCommand(insertInvoiceQuery, conn, trans))
                    {
                        invCmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo);
                        invCmd.Parameters.AddWithValue("@CustomerName", customerName);
                        invCmd.Parameters.AddWithValue("@CustomerPhone", string.IsNullOrWhiteSpace(customerPhone) ? (object)DBNull.Value : customerPhone);
                        invCmd.Parameters.AddWithValue("@CreatedBy", createdBy);
                        invCmd.Parameters.AddWithValue("@TotalAmount", grandTotal);

                        invoiceId = Convert.ToInt32(invCmd.ExecuteScalar());
                    }

                    // 3. Insert Invoice Details and Deduct Stock
                    foreach (DataRow row in items.Rows)
                    {
                        int productId = Convert.ToInt32(row["ProductId"]);
                        string prodName = Convert.ToString(row["ProductName"]);
                        int qty = Convert.ToInt32(row["Quantity"]);
                        decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                        decimal lineTotal = qty * unitPrice;

                        // Insert detail
                        string insertDetailQuery = @"
                            INSERT INTO InvoiceDetails (InvoiceId, ProductId, ProductName, Quantity, UnitPrice, TotalAmount)
                            VALUES (@InvoiceId, @ProductId, @ProductName, @Quantity, @UnitPrice, @TotalAmount);";

                        using (var detCmd = new MySqlCommand(insertDetailQuery, conn, trans))
                        {
                            detCmd.Parameters.AddWithValue("@InvoiceId", invoiceId);
                            detCmd.Parameters.AddWithValue("@ProductId", productId);
                            detCmd.Parameters.AddWithValue("@ProductName", prodName);
                            detCmd.Parameters.AddWithValue("@Quantity", qty);
                            detCmd.Parameters.AddWithValue("@UnitPrice", unitPrice);
                            detCmd.Parameters.AddWithValue("@TotalAmount", lineTotal);
                            detCmd.ExecuteNonQuery();
                        }

                        // Deduct stock from real products list
                        string deductStockQuery = @"
                            UPDATE Products 
                            SET Quantity = Quantity - @Quantity, 
                                UpdatedDate = NOW() 
                            WHERE ProductId = @ProductId;";

                        using (var stockCmd = new MySqlCommand(deductStockQuery, conn, trans))
                        {
                            stockCmd.Parameters.AddWithValue("@Quantity", qty);
                            stockCmd.Parameters.AddWithValue("@ProductId", productId);
                            stockCmd.ExecuteNonQuery();
                        }
                    }

                    trans.Commit();
                    return true;
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    errorMessage = ex.Message;
                    return false;
                }
            }
        }

        public DataTable GetInvoiceHistory(int? createdBy = null)
        {
            string query = @"
                SELECT 
                    i.InvoiceId, 
                    i.InvoiceNo, 
                    i.CustomerName, 
                    i.CustomerPhone, 
                    i.TotalAmount, 
                    i.InvoiceDate,
                    u.Name AS CreatedByName,
                    u.Role AS CreatedByRole
                FROM Invoices i
                INNER JOIN Users u ON i.CreatedBy = u.UserId " +
                (createdBy.HasValue ? "WHERE i.CreatedBy = @CreatedBy " : "") +
                "ORDER BY i.InvoiceId DESC;";

            var parameters = createdBy.HasValue 
                ? new[] { new MySqlParameter("@CreatedBy", createdBy.Value) } 
                : null;

            return DbHelper.ExecuteDataTable(query, parameters);
        }

        public DataTable GetInvoiceHeader(int invoiceId)
        {
            string query = @"
                SELECT 
                    i.InvoiceId, 
                    i.InvoiceNo, 
                    i.CustomerName, 
                    i.CustomerPhone, 
                    i.TotalAmount, 
                    i.InvoiceDate,
                    u.Name AS CreatedByName,
                    u.Username AS CreatedByUsername
                FROM Invoices i
                INNER JOIN Users u ON i.CreatedBy = u.UserId
                WHERE i.InvoiceId = @InvoiceId;";

            var parameters = new[] { new MySqlParameter("@InvoiceId", invoiceId) };
            return DbHelper.ExecuteDataTable(query, parameters);
        }

        public DataTable GetInvoiceDetails(int invoiceId)
        {
            string query = @"
                SELECT 
                    d.InvoiceDetailId, 
                    d.InvoiceId, 
                    d.ProductId, 
                    d.ProductName, 
                    d.Quantity, 
                    d.UnitPrice, 
                    d.TotalAmount,
                    p.ProductCode,
                    p.ImagePath
                FROM InvoiceDetails d
                LEFT JOIN Products p ON d.ProductId = p.ProductId
                WHERE d.InvoiceId = @InvoiceId;";

            var parameters = new[] { new MySqlParameter("@InvoiceId", invoiceId) };
            return DbHelper.ExecuteDataTable(query, parameters);
        }

        public DataTable GetDashboardMetrics()
        {
            string query = @"
                SELECT 
                    (SELECT COUNT(*) FROM Products WHERE IsActive = 1) AS TotalProducts,
                    (SELECT COUNT(*) FROM Products WHERE IsActive = 1 AND Quantity <= 10) AS LowStockProducts,
                    (SELECT COUNT(*) FROM Invoices) AS TotalInvoices,
                    (SELECT COALESCE(SUM(TotalAmount), 0) FROM Invoices) AS TotalRevenue,
                    (SELECT COUNT(*) FROM Users WHERE Role = 'Employee' AND IsActive = 1) AS TotalEmployees;";

            return DbHelper.ExecuteDataTable(query);
        }
    }
}
