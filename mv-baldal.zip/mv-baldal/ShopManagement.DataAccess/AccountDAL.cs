using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class AccountDAL
    {
        public DataTable ValidateUser(string username, string password)
        {
            string query = @"SELECT UserId, Name, Username, Role, IsActive 
                             FROM Users 
                             WHERE Username = @Username AND PasswordHash = @Password AND IsActive = 1;";
            
            var parameters = new[]
            {
                new MySqlParameter("@Username", username),
                new MySqlParameter("@Password", password)
            };

            return DbHelper.ExecuteDataTable(query, parameters);
        }
    }
}
