using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class StoreDAL
    {
        public DataTable GetAllStores(bool activeOnly = false)
        {
            string query = activeOnly
                ? @"SELECT StoreId, StoreCode, StoreName, Address, Phone, Email, IsActive, CreatedDate
                    FROM Stores WHERE IsActive = 1 ORDER BY StoreName ASC;"
                : @"SELECT StoreId, StoreCode, StoreName, Address, Phone, Email, IsActive, CreatedDate
                    FROM Stores ORDER BY StoreId DESC;";
            return DbHelper.ExecuteDataTable(query);
        }

        public DataTable GetStoreById(int storeId)
        {
            string query = @"SELECT StoreId, StoreCode, StoreName, Address, Phone, Email, IsActive 
                             FROM Stores WHERE StoreId = @StoreId;";
            return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@StoreId", storeId) });
        }

        public bool CreateStore(string storeCode, string storeName, string address, string phone, string email, out string errorMessage)
        {
            errorMessage = string.Empty;
            try
            {
                string query = @"INSERT INTO Stores (StoreCode, StoreName, Address, Phone, Email, IsActive, CreatedDate)
                                 VALUES (@StoreCode, @StoreName, @Address, @Phone, @Email, 1, NOW());";
                var parameters = new[]
                {
                    new MySqlParameter("@StoreCode", storeCode),
                    new MySqlParameter("@StoreName", storeName),
                    new MySqlParameter("@Address", string.IsNullOrWhiteSpace(address) ? (object)DBNull.Value : address),
                    new MySqlParameter("@Phone", string.IsNullOrWhiteSpace(phone) ? (object)DBNull.Value : phone),
                    new MySqlParameter("@Email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email)
                };
                return DbHelper.ExecuteNonQuery(query, parameters) > 0;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message.Contains("Duplicate") ? "Store code already exists." : ex.Message;
                return false;
            }
        }

        public bool UpdateStore(int storeId, string storeName, string address, string phone, string email, bool isActive)
        {
            string query = @"UPDATE Stores SET StoreName = @StoreName, Address = @Address, Phone = @Phone,
                             Email = @Email, IsActive = @IsActive, UpdatedDate = NOW()
                             WHERE StoreId = @StoreId;";
            var parameters = new[]
            {
                new MySqlParameter("@StoreId", storeId),
                new MySqlParameter("@StoreName", storeName),
                new MySqlParameter("@Address", string.IsNullOrWhiteSpace(address) ? (object)DBNull.Value : address),
                new MySqlParameter("@Phone", string.IsNullOrWhiteSpace(phone) ? (object)DBNull.Value : phone),
                new MySqlParameter("@Email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email),
                new MySqlParameter("@IsActive", isActive ? 1 : 0)
            };
            return DbHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        public bool DeleteStore(int storeId)
        {
            string query = "UPDATE Stores SET IsActive = 0, UpdatedDate = NOW() WHERE StoreId = @StoreId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@StoreId", storeId) }) > 0;
        }

        public DataTable GetStoreStats()
        {
            string query = @"
                SELECT 
                    s.StoreId, s.StoreName, s.StoreCode, s.IsActive,
                    COUNT(DISTINCT u.UserId) AS TotalEmployees,
                    COUNT(DISTINCT i.InvoiceId) AS TotalInvoices,
                    COALESCE(SUM(i.TotalAmount), 0) AS TotalRevenue
                FROM Stores s
                LEFT JOIN Users u ON u.StoreId = s.StoreId AND u.Role = 'Employee' AND u.IsActive = 1
                LEFT JOIN Invoices i ON i.StoreId = s.StoreId
                GROUP BY s.StoreId, s.StoreName, s.StoreCode, s.IsActive
                ORDER BY s.StoreId ASC;";
            return DbHelper.ExecuteDataTable(query);
        }
    }
}
