using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class ProductDAL
    {
        public DataTable GetAllProducts(bool activeOnly = true)
        {
            string query = activeOnly
                ? "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate, UpdatedDate FROM Products WHERE IsActive = 1 ORDER BY ProductId DESC;"
                : "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate, UpdatedDate FROM Products ORDER BY ProductId DESC;";
            return DbHelper.ExecuteDataTable(query);
        }

        public DataTable GetProductById(int productId)
        {
            string query = "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath, IsActive FROM Products WHERE ProductId = @ProductId;";
            return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@ProductId", productId) });
        }

        public DataTable CheckProductExists(string productCode, string productName)
        {
            string query = "SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath FROM Products WHERE ProductCode = @ProductCode OR LOWER(ProductName) = LOWER(@ProductName) LIMIT 1;";
            var parameters = new[]
            {
                new MySqlParameter("@ProductCode", productCode ?? string.Empty),
                new MySqlParameter("@ProductName", productName ?? string.Empty)
            };
            return DbHelper.ExecuteDataTable(query, parameters);
        }

        // Upsert: insert or increment stock if product already exists
        public bool UpsertProduct(string productCode, string productName, int quantity, decimal price, string imagePath, out string operation)
        {
            var dtExisting = CheckProductExists(productCode, productName);

            if (dtExisting != null && dtExisting.Rows.Count > 0)
            {
                int existingId = Convert.ToInt32(dtExisting.Rows[0]["ProductId"]);
                string existingImage = Convert.ToString(dtExisting.Rows[0]["ImagePath"]);

                // Keep existing image if no new image is provided
                string resolvedImage = string.IsNullOrWhiteSpace(imagePath) ? existingImage : imagePath;

                string updateQuery = @"
                    UPDATE Products 
                    SET ProductName  = @ProductName,
                        Quantity     = Quantity + @Quantity,
                        Price        = @Price,
                        ImagePath    = @ImagePath,
                        IsActive     = 1,
                        UpdatedDate  = NOW()
                    WHERE ProductId  = @ProductId;";

                var updateParams = new[]
                {
                    new MySqlParameter("@ProductId",   existingId),
                    new MySqlParameter("@ProductName", productName),
                    new MySqlParameter("@Quantity",    quantity),
                    new MySqlParameter("@Price",       price),
                    new MySqlParameter("@ImagePath",   resolvedImage ?? "/images/products/default-product.svg")
                };

                int rows = DbHelper.ExecuteNonQuery(updateQuery, updateParams);
                operation = "Updated (Stock Incremented)";
                return rows > 0;
            }
            else
            {
                string defaultImage = string.IsNullOrWhiteSpace(imagePath)
                    ? "/images/products/default-product.svg"
                    : imagePath;

                string insertQuery = @"
                    INSERT INTO Products (ProductCode, ProductName, Quantity, Price, ImagePath, IsActive, CreatedDate)
                    VALUES (@ProductCode, @ProductName, @Quantity, @Price, @ImagePath, 1, NOW());";

                var insertParams = new[]
                {
                    new MySqlParameter("@ProductCode", productCode),
                    new MySqlParameter("@ProductName", productName),
                    new MySqlParameter("@Quantity",    quantity),
                    new MySqlParameter("@Price",       price),
                    new MySqlParameter("@ImagePath",   defaultImage)
                };

                int rows = DbHelper.ExecuteNonQuery(insertQuery, insertParams);
                operation = "Created New Product";
                return rows > 0;
            }
        }

        // Edit existing product (full update – does NOT increment stock, sets exact qty)
        public bool UpdateProduct(int productId, string productName, int quantity, decimal price, string newImagePath, out string errorMessage)
        {
            errorMessage = string.Empty;
            try
            {
                string query;
                MySqlParameter[] parameters;

                if (string.IsNullOrWhiteSpace(newImagePath))
                {
                    // Keep existing image
                    query = @"UPDATE Products
                              SET ProductName  = @ProductName,
                                  Quantity     = @Quantity,
                                  Price        = @Price,
                                  UpdatedDate  = NOW()
                              WHERE ProductId  = @ProductId;";
                    parameters = new[]
                    {
                        new MySqlParameter("@ProductId",   productId),
                        new MySqlParameter("@ProductName", productName),
                        new MySqlParameter("@Quantity",    quantity),
                        new MySqlParameter("@Price",       price)
                    };
                }
                else
                {
                    query = @"UPDATE Products
                              SET ProductName  = @ProductName,
                                  Quantity     = @Quantity,
                                  Price        = @Price,
                                  ImagePath    = @ImagePath,
                                  UpdatedDate  = NOW()
                              WHERE ProductId  = @ProductId;";
                    parameters = new[]
                    {
                        new MySqlParameter("@ProductId",   productId),
                        new MySqlParameter("@ProductName", productName),
                        new MySqlParameter("@Quantity",    quantity),
                        new MySqlParameter("@Price",       price),
                        new MySqlParameter("@ImagePath",   newImagePath)
                    };
                }

                return DbHelper.ExecuteNonQuery(query, parameters) > 0;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        public bool DeleteProduct(int productId)
        {
            string query = "UPDATE Products SET IsActive = 0, UpdatedDate = NOW() WHERE ProductId = @ProductId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@ProductId", productId) }) > 0;
        }

        public DataTable SearchAvailableProducts(string term)
        {
            string query = @"SELECT ProductId, ProductCode, ProductName, Quantity, Price, ImagePath
                             FROM Products
                             WHERE IsActive = 1 AND Quantity > 0
                               AND (ProductName LIKE @Term OR ProductCode LIKE @Term)
                             ORDER BY ProductName ASC;";
            return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@Term", "%" + (term ?? "") + "%") });
        }
    }
}
