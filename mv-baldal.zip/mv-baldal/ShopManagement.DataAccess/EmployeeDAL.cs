using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public class EmployeeDAL
    {
        public DataTable GetAllEmployees()
        {
            try
            {
                string query = @"SELECT u.UserId, u.Name, u.Username, u.Role, u.IsActive, u.CreatedDate,
                                        u.StoreId, COALESCE(s.StoreName, 'Main Branch') AS StoreName
                                 FROM Users u
                                 LEFT JOIN Stores s ON s.StoreId = u.StoreId
                                 WHERE u.Role = 'Employee'
                                 ORDER BY u.UserId DESC;";
                return DbHelper.ExecuteDataTable(query);
            }
            catch
            {
                string fallbackQuery = @"SELECT u.UserId, u.Name, u.Username, u.Role, u.IsActive, u.CreatedDate,
                                                1 AS StoreId, 'Main Branch' AS StoreName
                                         FROM Users u
                                         WHERE u.Role = 'Employee'
                                         ORDER BY u.UserId DESC;";
                return DbHelper.ExecuteDataTable(fallbackQuery);
            }
        }

        public DataTable GetEmployeeById(int userId)
        {
            try
            {
                string query = @"SELECT u.UserId, u.Name, u.Username, u.Role, u.IsActive, u.StoreId,
                                        COALESCE(s.StoreName, 'Main Branch') AS StoreName
                                 FROM Users u
                                 LEFT JOIN Stores s ON s.StoreId = u.StoreId
                                 WHERE u.UserId = @UserId;";
                return DbHelper.ExecuteDataTable(query, new[] { new MySqlParameter("@UserId", userId) });
            }
            catch
            {
                string fallbackQuery = @"SELECT u.UserId, u.Name, u.Username, u.Role, u.IsActive, 1 AS StoreId, 'Main Branch' AS StoreName
                                         FROM Users u
                                         WHERE u.UserId = @UserId;";
                return DbHelper.ExecuteDataTable(fallbackQuery, new[] { new MySqlParameter("@UserId", userId) });
            }
        }

        public bool CreateEmployee(string name, string username, string password, int? storeId)
        {
            try
            {
                string query = @"INSERT INTO Users (Name, Username, PasswordHash, Role, StoreId, IsActive, CreatedDate)
                                 VALUES (@Name, @Username, @Password, 'Employee', @StoreId, 1, NOW());";
                var parameters = new[]
                {
                    new MySqlParameter("@Name",     name),
                    new MySqlParameter("@Username", username),
                    new MySqlParameter("@Password", password),
                    new MySqlParameter("@StoreId",  storeId.HasValue ? (object)storeId.Value : DBNull.Value)
                };
                return DbHelper.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                string fallbackQuery = @"INSERT INTO Users (Name, Username, PasswordHash, Role, IsActive, CreatedDate)
                                         VALUES (@Name, @Username, @Password, 'Employee', 1, NOW());";
                var parameters = new[]
                {
                    new MySqlParameter("@Name",     name),
                    new MySqlParameter("@Username", username),
                    new MySqlParameter("@Password", password)
                };
                return DbHelper.ExecuteNonQuery(fallbackQuery, parameters) > 0;
            }
        }

        public bool UpdateEmployee(int userId, string name, string password, bool isActive, int? storeId)
        {
            try
            {
                string query;
                MySqlParameter[] parameters;

                if (string.IsNullOrWhiteSpace(password))
                {
                    query = @"UPDATE Users SET Name = @Name, IsActive = @IsActive, StoreId = @StoreId,
                              UpdatedDate = NOW() WHERE UserId = @UserId;";
                    parameters = new[]
                    {
                        new MySqlParameter("@UserId",  userId),
                        new MySqlParameter("@Name",    name),
                        new MySqlParameter("@IsActive",isActive ? 1 : 0),
                        new MySqlParameter("@StoreId", storeId.HasValue ? (object)storeId.Value : DBNull.Value)
                    };
                }
                else
                {
                    query = @"UPDATE Users SET Name = @Name, PasswordHash = @Password, IsActive = @IsActive,
                              StoreId = @StoreId, UpdatedDate = NOW() WHERE UserId = @UserId;";
                    parameters = new[]
                    {
                        new MySqlParameter("@UserId",   userId),
                        new MySqlParameter("@Name",     name),
                        new MySqlParameter("@Password", password),
                        new MySqlParameter("@IsActive", isActive ? 1 : 0),
                        new MySqlParameter("@StoreId",  storeId.HasValue ? (object)storeId.Value : DBNull.Value)
                    };
                }

                return DbHelper.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                string fallbackQuery = string.IsNullOrWhiteSpace(password)
                    ? @"UPDATE Users SET Name = @Name, IsActive = @IsActive, UpdatedDate = NOW() WHERE UserId = @UserId;"
                    : @"UPDATE Users SET Name = @Name, PasswordHash = @Password, IsActive = @IsActive, UpdatedDate = NOW() WHERE UserId = @UserId;";

                var parameters = string.IsNullOrWhiteSpace(password)
                    ? new[]
                    {
                        new MySqlParameter("@UserId",   userId),
                        new MySqlParameter("@Name",     name),
                        new MySqlParameter("@IsActive", isActive ? 1 : 0)
                    }
                    : new[]
                    {
                        new MySqlParameter("@UserId",   userId),
                        new MySqlParameter("@Name",     name),
                        new MySqlParameter("@Password", password),
                        new MySqlParameter("@IsActive", isActive ? 1 : 0)
                    };

                return DbHelper.ExecuteNonQuery(fallbackQuery, parameters) > 0;
            }
        }

        public bool ResetPassword(int userId, string newPassword)
        {
            string query = "UPDATE Users SET PasswordHash = @Password, UpdatedDate = NOW() WHERE UserId = @UserId;";
            var parameters = new[]
            {
                new MySqlParameter("@UserId", userId),
                new MySqlParameter("@Password", newPassword)
            };
            return DbHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        public bool ToggleStatus(int userId)
        {
            string query = "UPDATE Users SET IsActive = CASE WHEN IsActive = 1 THEN 0 ELSE 1 END, UpdatedDate = NOW() WHERE UserId = @UserId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@UserId", userId) }) > 0;
        }

        public bool DeleteEmployee(int userId)
        {
            string query = "UPDATE Users SET IsActive = 0, UpdatedDate = NOW() WHERE UserId = @UserId;";
            return DbHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@UserId", userId) }) > 0;
        }
    }
}
