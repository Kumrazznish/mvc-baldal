using System;
using System.Data;
using MySqlConnector;

namespace ShopManagement.DataAccess
{
    public static class DbHelper
    {
        public static string ConnectionString { get; set; } = "Server=localhost;Database=ShopManagementDB;User ID=root;Password=root;Port=3306;AllowUserVariables=True;";

        public static MySqlConnection GetConnection()
        {
            var conn = new MySqlConnection(ConnectionString);
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            return conn;
        }

        public static DataTable ExecuteDataTable(string query, MySqlParameter[] parameters = null, CommandType commandType = CommandType.Text)
        {
            var dt = new DataTable();
            using (var conn = GetConnection())
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.CommandType = commandType;
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }

                using (var adapter = new MySqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        public static int ExecuteNonQuery(string query, MySqlParameter[] parameters = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = GetConnection())
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.CommandType = commandType;
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteNonQuery();
            }
        }

        public static object ExecuteScalar(string query, MySqlParameter[] parameters = null, CommandType commandType = CommandType.Text)
        {
            using (var conn = GetConnection())
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.CommandType = commandType;
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteScalar();
            }
        }

        public static void InitializeDatabase()
        {
            try
            {
                // 1. Create tables if not exist
                string createTablesSql = @"
CREATE TABLE IF NOT EXISTS Users (
    UserId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Username VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL,
    StoreId INT NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

CREATE TABLE IF NOT EXISTS Stores (
    StoreId INT AUTO_INCREMENT PRIMARY KEY,
    StoreName VARCHAR(200) NOT NULL,
    StoreCode VARCHAR(50) NOT NULL UNIQUE,
    Address VARCHAR(500) NULL,
    Phone VARCHAR(20) NULL,
    Email VARCHAR(150) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

CREATE TABLE IF NOT EXISTS Products (
    ProductId INT AUTO_INCREMENT PRIMARY KEY,
    ProductCode VARCHAR(50) NOT NULL UNIQUE,
    ProductName VARCHAR(200) NOT NULL,
    Quantity INT NOT NULL DEFAULT 0,
    Price DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    ImagePath VARCHAR(500) NULL,
    IsActive TINYINT(1) NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedDate DATETIME NULL
);

CREATE TABLE IF NOT EXISTS Invoices (
    InvoiceId INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceNo VARCHAR(30) NOT NULL UNIQUE,
    CustomerName VARCHAR(150) NOT NULL,
    CustomerPhone VARCHAR(20) NULL,
    CreatedBy INT NOT NULL,
    StoreId INT NULL,
    InvoiceDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0.00
);

CREATE TABLE IF NOT EXISTS InvoiceDetails (
    InvoiceDetailId INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceId INT NOT NULL,
    ProductId INT NOT NULL,
    ProductName VARCHAR(200) NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    TotalAmount DECIMAL(18,2) NOT NULL
);
";
                ExecuteNonQuery(createTablesSql);

                // 2. Ensure StoreId column exists in Users
                try
                {
                    ExecuteNonQuery("ALTER TABLE Users ADD COLUMN StoreId INT NULL AFTER Role;");
                }
                catch { /* Ignore if already exists */ }

                // 3. Ensure StoreId column exists in Invoices
                try
                {
                    ExecuteNonQuery("ALTER TABLE Invoices ADD COLUMN StoreId INT NULL AFTER TotalAmount;");
                }
                catch { /* Ignore if already exists */ }

                // 4. Seed default admin and desk login if missing
                try
                {
                    ExecuteNonQuery(@"
INSERT IGNORE INTO Users (UserId, Name, Username, PasswordHash, Role, IsActive)
VALUES 
(1, 'System Admin', 'admin', 'admin123', 'Admin', 1),
(2, 'Desk Cashier', 'desk1', 'desk123', 'Employee', 1);
");
                }
                catch { /* Ignore if already exists */ }

                // 5. Seed default store
                try
                {
                    ExecuteNonQuery(@"
INSERT IGNORE INTO Stores (StoreId, StoreName, StoreCode, Address, Phone, Email, IsActive)
VALUES (1, 'Main Branch', 'MAIN01', '123 Market Road, City Centre', '9800000001', 'main@shopdesk.local', 1);
");
                }
                catch { /* Ignore */ }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DbHelper.InitializeDatabase] Warning: {ex.Message}");
            }
        }
    }
}
